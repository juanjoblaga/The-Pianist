'use strict';
// Offline canvas game. Logical coordinates: 960 × 640. All furniture and collisions
// are data-driven; edit OBJECTS to change placement or interaction labels.
(()=>{
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const W=960,H=640;canvas.width=W;canvas.height=H;ctx.imageSmoothingEnabled=false;
const C={outline:'#302b33',wall:'#e7dac5',wallShadow:'#b8a990',wood:'#b98350',wood2:'#c88d57',wood3:'#a66c42',tile:'#92959b',teal:'#244d51',teal2:'#34666a',linen:'#e9dfcf',blue:'#446987',dark:'#292f3b',plant:'#3b7148',plant2:'#7ca56b'};
const walls=[{x:30,y:95,w:16,h:492},{x:30,y:570,w:900,h:17},{x:914,y:95,w:16,h:492},{x:30,y:95,w:900,h:16},
// Bedroom: right upper corner, with single doorway on its bottom edge
{x:610,y:105,w:14,h:260},{x:610,y:365,w:125,h:14},{x:804,y:365,w:110,h:14},
// Bathroom: right lower corner, single doorway on its left edge
{x:735,y:400,w:179,h:14},{x:735,y:400,w:14,h:58},{x:735,y:526,w:14,h:44}];
const OBJECTS=[
{name:'Balcony door',x:95,y:108,w:395,h:16,solid:true,type:'glass'},
{name:'Balcony',x:85,y:20,w:420,h:73,solid:false,type:'balcony'},
{name:'Sofa',x:112,y:150,w:242,h:107,solid:true,type:'sofa'},
{name:'Coffee table',x:265,y:268,w:108,h:58,solid:true,type:'coffee'},
{name:'Floor lamp',x:80,y:222,w:30,h:30,solid:true,type:'lamp'},
{name:'Bookshelf',x:62,y:292,w:45,h:132,solid:true,type:'shelf'},
{name:'Piano',x:535,y:175,w:60,h:173,solid:true,type:'piano'},
{name:'Dining table',x:248,y:378,w:178,h:102,solid:true,type:'dining'},
{name:'Kitchen counter',x:63,y:490,w:460,h:62,solid:true,type:'counter'},
{name:'Kitchen sink',x:63,y:350,w:48,h:142,solid:true,type:'sink'},
{name:'Bed',x:698,y:155,w:158,h:166,solid:true,type:'bed'},
{name:'Wardrobe',x:638,y:128,w:43,h:175,solid:true,type:'wardrobe'},
{name:'Bedside table',x:862,y:162,w:36,h:50,solid:true,type:'side'},
{name:'Bathroom sink',x:766,y:432,w:57,h:50,solid:true,type:'bathSink'},
{name:'Toilet',x:833,y:433,w:43,h:63,solid:true,type:'toilet'},
{name:'Bathtub',x:810,y:515,w:93,h:42,solid:true,type:'bath'},
{name:'Entry console',x:620,y:520,w:74,h:35,solid:true,type:'console'}
];
const player={x:471,y:348,dir:'down',walk:0};const keys=new Set();let joy={x:0,y:0},last=0,toastTimer=0;
function rect(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h))}
function box(x,y,w,h,fill,border=C.outline){rect(x-3,y-3,w+6,h+6,border);rect(x,y,w,h,fill)}
function line(x,y,x2,y2,color,width=2){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x2,y2);ctx.stroke()}
function plant(x,y){rect(x-7,y+3,14,10,'#a9744d');for(let i=0;i<7;i++){let a=i*Math.PI*2/7;line(x,y+3,x+Math.cos(a)*12,y+Math.sin(a)*12,i%2?C.plant:C.plant2,4)}}
function floor(x,y,w,h,color,step=34){rect(x,y,w,h,color);for(let yy=y;yy<y+h;yy+=step){line(x,yy,x+w,yy,'#986b4c44',1);for(let xx=x+((Math.floor(yy/step)%2)*step/2);xx<x+w;xx+=step*2)line(xx,yy,xx,Math.min(yy+step,y+h),'#986b4c55',1)}}
function drawObject(o){const{x,y,w,h,type}=o;switch(type){
case'balcony':rect(x,y,w,h,'#8b684e');for(let i=0;i<8;i++)line(x,y+i*10,x+w,y+i*10,'#684e3f',2);for(let i=0;i<7;i++)rect(x+25+i*55,y+6,5,5,'#ffda8c');box(x+100,y+20,55,34,'#b38c62');box(x+170,y+28,25,25,'#a78058');plant(x+25,y+35);break;
case'glass':rect(x,y,w,h,'#91bbc0');for(let i=1;i<4;i++)rect(x+i*w/4-2,y,4,h,'#e5e0d1');break;
case'sofa':box(x,y,w,h,C.teal);rect(x+12,y+12,w-24,28,C.teal2);rect(x+12,y+44,52,h-56,C.teal2);rect(x+69,y+44,w-81,h-56,'#2c5b5f');line(x+147,y+44,x+147,y+h-12,'#1c4044',3);rect(x+w-52,y+62,27,20,'#677c86');break;
case'coffee':box(x,y,w,h,'#986c4b');rect(x+9,y+9,w-18,h-18,'#b8895e');plant(x+26,y+24);rect(x+60,y+20,23,17,'#e0d1b3');break;
case'lamp':rect(x-3,y-35,5,55,C.dark);rect(x-3,y-35,75,4,C.dark);rect(x+58,y-33,28,25,'#f1d08c');rect(x+60,y-31,24,21,'#ffe4a7');break;
case'shelf':box(x,y,w,h,'#8b6145');for(let i=0;i<4;i++){rect(x+4,y+i*30+7,w-8,4,'#d1ad7b');rect(x+9,y+i*30+12,8,15,i%2?'#7e8f85':'#b6a078');rect(x+20,y+i*30+12,8,15,'#6f7d9a')}break;
case'piano':box(x,y,w,h,'#1e2730');rect(x+8,y+22,34,h-44,'#ece9df');for(let i=0;i<14;i++){line(x+8,y+22+i*9,x+42,y+22+i*9,'#252b34',2);if(i%2)rect(x+8,y+20+i*9,20,5,'#252b34')}box(x-18,y+64,13,48,'#332b2b');break;
case'dining':box(x,y,w,h,'#9c6b44');rect(x+7,y+7,w-14,h-14,'#bb895b');for(let i=0;i<4;i++){let cx=x+32+i*39;rect(cx,y-21,28,16,'#a4a1a0');rect(cx,y+h+5,28,16,'#a4a1a0')}rect(x+70,y+35,14,20,'#d9c298');rect(x+95,y+39,28,17,'#a77738');break;
case'counter':box(x,y,w,h,'#e6e0d7');rect(x+2,y+2,w-4,16,'#bb936c');rect(x+145,y+19,75,32,'#31353b');for(let i=0;i<4;i++)rect(x+155+(i%2)*35,y+24+Math.floor(i/2)*15,18,10,'#64666a');rect(x+355,y+16,52,44,'#9da4a6');break;
case'sink':box(x,y,w,h,'#e2dbd1');rect(x+7,y+35,w-14,46,'#889ca0');rect(x+13,y+42,w-26,30,'#c4d2d3');break;
case'bed':box(x,y,w,h,'#a47652');rect(x+9,y+10,w-18,h-20,C.linen);rect(x+12,y+12,63,36,'#e6e5dc');rect(x+82,y+12,63,36,'#e6e5dc');for(let i=0;i<8;i++){rect(x+17+i*17,y+18,6,5,C.blue);rect(x+17+i*17,y+38,6,4,C.blue)}rect(x+9,y+92,w-18,62,'#557d99');for(let i=0;i<8;i++)line(x+14+i*17,y+100,x+25+i*17,y+147,'#b7cbd6',2);break;
case'wardrobe':box(x,y,w,h,'#c7b99f');rect(x+13,y+7,18,h-14,'#a3bbc2');line(x+36,y+8,x+36,y+h-8,'#8b806d');break;
case'side':box(x,y,w,h,'#9d7756');rect(x+7,y+9,w-14,7,'#e5c78a');break;
case'bathSink':box(x,y,w,h,'#e7e6e0');rect(x+10,y+12,w-20,h-24,'#b4c8cc');break;
case'toilet':box(x,y,w,h,'#f0eee9');rect(x+9,y+19,w-18,h-26,'#bbcbd0');break;
case'bath':box(x,y,w,h,'#f1eee8');rect(x+9,y+7,w-18,h-14,'#afc6cc');break;
case'console':box(x,y,w,h,'#a27854');rect(x+8,y+9,12,12,'#e0c2a0');plant(x+51,y+12);break;
}}
function drawMap(){rect(0,0,W,H,'#171a23');box(26,91,908,500,C.wall);floor(47,112,866,455,C.wood2);floor(625,113,288,250,'#9a8580',22);floor(750,415,163,152,'#8e9497',27);
for(const o of OBJECTS)if(o.type==='balcony')drawObject(o);
// decorative rugs, behind furniture
rect(105,143,276,200,'#a69a88');rect(112,150,262,186,'#c2b3a1');rect(683,145,189,191,'#b7a9a2');
for(const o of OBJECTS)if(o.type!=='balcony')drawObject(o);
// single bedroom opening, single bathroom opening
for(const w of walls)rect(w.x,w.y,w.w,w.h,C.outline);
rect(738,366,64,11,'#b88a61');rect(735,459,11,66,'#b88a61');
// front entrance (one main door) on bottom edge
rect(524,569,83,19,C.wood3);rect(538,574,54,13,'#d7b78c');rect(542,591,48,18,'#66816a');
// top balcony rail
rect(85,13,420,7,'#a8a9a7');for(let x=85;x<506;x+=36)rect(x,13,4,17,'#a8a9a7');
plant(488,140);plant(893,333);plant(68,129);
}
function drawPlayer(){let{x,y,dir,walk}=player;let stride=Math.sin(walk)*3;rect(x-11,y+13,23,6,'#0005');rect(x-9,y+5,7,12,C.dark);rect(x+2,y+5+stride,7,12,C.dark);box(x-12,y-21,24,28,'#222b34');rect(x-15,y-16,4,17,'#d7ab87');rect(x+11,y-16,4,17,'#d7ab87');rect(x-11,y-40,22,22,'#d8a884');rect(x-13,y-43,26,10,'#543a2c');rect(x-8,y-47,14,6,'#543a2c');rect(x+3,y-45,11,5,'#543a2c');if(dir!=='up'){rect(x-6,y-30,3,3,'#2c282a');rect(x+4,y-30,3,3,'#2c282a')}if(dir==='left')rect(x+5,y-30,4,5,'#d8a884');if(dir==='right')rect(x-9,y-30,4,5,'#d8a884')}
function blocked(x,y){const r=9;if(x<55||x>902||y<128||y>556)return true;for(const w of walls)if(x+r>w.x&&x-r<w.x+w.w&&y+r>w.y&&y-r<w.y+w.h)return true;for(const o of OBJECTS)if(o.solid&&o.type!=='glass'&&x+r>o.x&&x-r<o.x+o.w&&y+r>o.y&&y-r<o.y+o.h)return true;return false}
function closest(){let best=null,d=72;for(const o of OBJECTS){if(o.type==='balcony'||o.type==='glass')continue;const cx=Math.max(o.x,Math.min(player.x,o.x+o.w)),cy=Math.max(o.y,Math.min(player.y,o.y+o.h));let nd=Math.hypot(player.x-cx,player.y-cy);if(nd<d){d=nd;best=o}}return best}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2000)}
function interact(){const o=closest();toast(o?o.name:'Nothing to interact with nearby')}
function frame(ts){const dt=Math.min((ts-last)/1000||0,0.05);last=ts;let dx=joy.x,dy=joy.y;if(keys.has('ArrowLeft')||keys.has('a'))dx-=1;if(keys.has('ArrowRight')||keys.has('d'))dx+=1;if(keys.has('ArrowUp')||keys.has('w'))dy-=1;if(keys.has('ArrowDown')||keys.has('s'))dy+=1;let len=Math.hypot(dx,dy);if(len>0.08){dx/=len;dy/=len;let speed=145*dt;let nx=player.x+dx*speed,ny=player.y+dy*speed;if(!blocked(nx,player.y))player.x=nx;if(!blocked(player.x,ny))player.y=ny;player.walk+=dt*12;player.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up')}drawMap();drawPlayer();requestAnimationFrame(frame)}
const joyEl=document.getElementById('joystick'),stick=document.getElementById('stick');function moveStick(e){const b=joyEl.getBoundingClientRect(),cx=b.left+b.width/2,cy=b.top+b.height/2,dx=e.clientX-cx,dy=e.clientY-cy,dist=Math.hypot(dx,dy),limit=42,scale=Math.min(dist,limit)/(dist||1);let px=dx*scale,py=dy*scale;joy={x:px/limit,y:py/limit};stick.style.transform=`translate(${px}px,${py}px)`}function resetStick(){joy={x:0,y:0};stick.style.transform='translate(0,0)'}joyEl.addEventListener('pointerdown',e=>{joyEl.setPointerCapture(e.pointerId);moveStick(e)});joyEl.addEventListener('pointermove',e=>{if(joyEl.hasPointerCapture(e.pointerId))moveStick(e)});joyEl.addEventListener('pointerup',resetStick);joyEl.addEventListener('pointercancel',resetStick);
document.getElementById('action').addEventListener('pointerdown',e=>{e.preventDefault();interact()});document.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' ','e','w','a','s','d'].includes(e.key))e.preventDefault();if((e.key==='e'||e.key===' ')&&!e.repeat)interact();keys.add(e.key)});document.addEventListener('keyup',e=>keys.delete(e.key));window.addEventListener('blur',()=>{keys.clear();resetStick()});const modal=document.getElementById('modal');document.getElementById('help').onclick=()=>modal.hidden=false;document.getElementById('close').onclick=()=>modal.hidden=true;
requestAnimationFrame(frame);
})();
