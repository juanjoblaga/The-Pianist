# The Pianist — apartment prototype 0.1.0

A story-free, offline, landscape Android game prototype. No accounts, internet permission, tracking or external dependencies at runtime.

## Play in a browser
Open `game/index.html` in a desktop browser. Use WASD/arrow keys to move, E/Space to interact. On a touchscreen use the left joystick and right INTERACT button. The room is drawn in `game/game.js`; all objects are in the `OBJECTS` array.

## Build the Android APK with GitHub Actions
1. Create a **new** GitHub repository (e.g. `the-pianist`).
2. Upload the **contents of this ZIP** to the repository root, including the hidden `.github` directory. Alternatively unzip it and upload using Git or GitHub web upload.
3. Open **Actions → Build Android APK → Run workflow** (or push to main/master).
4. After the run succeeds, open its **Artifacts** and download `ThePianist-v0.1.0-debug-apk`.
5. Unzip the artifact, then install `app-debug.apk` on your Android phone. The APK is a debug-signed prototype; Android may ask you to allow installs from the source.

## Important
- Keep the same applicationId (`com.thepianist.game`) in later builds. To upgrade in place, the same signing key must be used. GitHub-hosted debug signing keys are ephemeral between runs, so **future debug APKs may not update this installation in place**. For a persistent installation, set up a stable release signing keystore before relying on app data. This build has no saved progress.
- The generated apartment is a newly drawn, simplified tile-style map based on the approved concept, not a direct slicing of the concept image.
- Character is an original small placeholder sprite inspired by the preferred dark-clothed protagonist, not a cut-out of the original reference artwork.
- The balcony is a visual feature; its door is not traversable in this first prototype.
- The bedroom and bathroom are walkable through their openings. The main entrance is decorative for now.
- To edit the game, update both `game/` and `app/src/main/assets/` with matching files.
