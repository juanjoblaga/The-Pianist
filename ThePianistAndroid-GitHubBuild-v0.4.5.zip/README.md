# The Pianist — v0.4.5 (Android GitHub Actions source)

This ZIP is a complete Android Gradle/WebView project, derived from the shipped v0.4.4 source. Upload it as **`ThePianistAndroid-GitHubBuild-v0.4.5.zip`** to the root of your existing The Pianist GitHub repository and run the existing **Build The Pianist APK** GitHub Actions workflow. The workflow is expected to use the highest versioned source ZIP. Install the resulting APK **over** your existing installation; do not uninstall.

## Newly implemented

**User-authored dialogue and eight original approved portraits.** No generated/replacement dialogue art; portraits are the exact images previously approved by the user (`portrait_*.png`). The current text is listed verbatim below. These interactions use the existing navy/gold portrait dialogue UI and context-sensitive actions.

| Location | Exact authored line |
|---|---|
| Piano | `I should definitely practice.` |
| Sofa | `Agggh... this sofa is truly the best <3` |
| Bed | `Time to get some rest.` |
| Balcony / balcony chair | `I don't use the balcony enough... I should come here more often.` |
| Beanbag | `Comfy.` |
| Front door | `Let's go.` |
| Kitchen | `I could go for some salmon. No time to cook though.` |
| Mirror | `Looking good! As always.` |
| Shower (before) | `Maybe I need a shower` |
| Shower (after) | `Nice and clean` |
| Toilet | `I dont need to use the toilet right now` |
| Wardrobe | `Just a bunch of clothes` |

The front-door `Leave` choice is visibly disabled until there is a scene to transition to. The bedroom window remains visible but has **no interaction** because it is inaccessible. Plants, dining table, intercom and coffee table have no dialogue/interaction. The previously authored bedroom-window line is **not used**; it remains reserved for a later project.

**Actions:** piano Play (silent until the user supplies their recording), sofa Sit, bed Sit/Lie down with approved duvet, beanbag and balcony chair Sit, balcony Look outside, shower Take shower. A small privacy mosaic/water animation stays within the shower cubicle; there is **no naked sprite**, and the character automatically returns to the bathroom with the authored post-shower line. No sofa reclining has been reinstated.

**Portraits and motion:** the eight exact official dialogue portraits are used without modifying their artwork; the four cardinal walking rows now use six-frame cycles including alternating side strides, and diagonal atlas has minor cleanup. Piano seated pose is preserved with a subtle four-frame hand extension toward the keys, still **silent**. Further character-portrait variants and new outfits were not created.

**Environment:** the five exterior time-of-day plates use the previously approved elevated fourth-floor building reference (warm neighbouring masonry, balconies, lit windows), not a jungle-like or geometric garden. The original apartment art, furnishings and plan are preserved. The game camera/canvas stops at the entrance threshold; the narrow masonry building fascia below the apartment wall is drawn without revealing a second playable scene. Bathroom mirror added above the existing sink. Furniture footprints and the sink/toilet/shower approach regions have been realigned to visible game positions.

## In-place update compatibility

- `applicationId`: **`com.thepianist.game`** (unchanged).
- `versionName`: **`0.4.5`**; `versionCode`: **`18`**.
- **Existing signing keystore** and Gradle signing configuration carried over byte-for-byte from v0.4.4.
- Existing saved-controls and sound keys **`thepianist.controls.v1`** and **`thepianist.sound.v1`** are unchanged; no save-wiping logic is added.
- Existing manifest, Java activity, icons, build workflow compatibility and package namespace are unchanged.

Back up any game settings/data before testing. Install over v0.4.4 without uninstalling. If Android reports a signing mismatch, stop instead of uninstalling.

## Verification and limitations

The HTML/JS/rendered artwork was exercised in headless Chromium with all five lighting and seven weather modes. The real game ran with no browser JavaScript exceptions. The actual dialogue menus, object approach geometry, visual mirror, balcony and shower assets were reviewed; the full shower sequence correctly ended with `Nice and clean` and an unposed player. `node --check` and ZIP integrity checks passed. **The Android APK itself has NOT been compiled or tested on a physical device in this environment**, so GitHub Actions and an in-place phone installation remain required. The updated piano and walking sprite sheets should be reviewed visually on the phone; passing browser tests is not a guarantee of perfect animation at the installed device's scale.
