# The Pianist v0.4.4 — quality gate

## Pass (source / game runtime)
- [x] No `trees_*.png`, synthetic `foliage_tips_v040.png` or `sofa_*.png` files remain in shipped assets.
- [x] New `world_{sunrise,morning,afternoon,sunset,night}.jpg` are 1536×1604 and taken from the previously approved detailed courtyard exterior, not flat/geometric garden assets.
- [x] One `drawWorldPlane(img, 0, -380, 1536, 1604)` renders behind all exterior openings. No disconnected balcony view or copied window crop.
- [x] Actual game screenshot visually inspected for balcony roof cap, window opening and background continuity.
- [x] Sofa shows Sit down / Examine only; Bed still shows Lie down; approved beanbag and upright sofa sit retained.
- [x] Outdoor rain screenshot inspected: no rain streaks through enclosed room floors.
- [x] All 5 daylight variants and all 7 weather choices loaded in browser.
- [x] Bedroom and bathroom wall, corridor clearance, rear balcony rail and sliding entrance collision checks passed.
- [x] JavaScript syntax valid, no browser runtime errors in QA tests.
- [x] Signing keystore byte-for-byte identical to v0.4.3; appId unchanged; version bumped to 0.4.4 (17).
- [x] Saved-controls storage name unchanged; no user data wipe logic added.

## Requires GitHub Actions / physical Android test
- [ ] `assembleDebug` succeeds on Android SDK (not installed in this test runtime).
- [ ] APK update installs in place and preserves the stored touch-button settings.
- [ ] Manual visual check at the actual phone's display aspect and scale.

## Explicitly not claimed fixed
The piano-playing and diagonal-walk sprite artwork is carried forward unchanged from v0.4.3. Sofa reclining has deliberately been removed, not replaced by an allegedly better sprite.
