# The Pianist — v0.4.4 (Android / GitHub Actions source)

This archive contains the complete Gradle Android WebView source project for v0.4.4. Upload the ZIP to the root of your existing **The Pianist** GitHub repository and run the existing **Build The Pianist APK** Actions workflow. That workflow selects the highest versioned `ThePianistAndroid-GitHubBuild-*.zip` and builds `assembleDebug`.

## Release scope — deliberately narrow and verifiable

- **One coherent exterior painting:** The old flat/geometric balcony backdrop and tree assets were deleted. All five outdoor time-of-day art plates now use only the exterior portions of the *previously approved painterly urban courtyard* artwork (`cozy_dusk_apartment_courtyard.png` used locally as a source/reference). They are each a **single 1536×1604 world image**, behind the existing apartment, balcony and bedroom window. There is **no separate balcony-view image**, independently cropped window scene, or repeated top strip. The original apartment plates and floorplan are not redesigned.
- **Balcony rear cap:** Corrected the earlier dark horizontal image strip above the balcony without removing the real railing, posts or wooden decking.
- **No unsuitable sofa recline:** The Sofa's `Lie down` choice and all existing reclining sprite assets are **removed entirely**. Its approved `Sit down` action remains. Bed lying and its duvet still work.
- **Outdoor weather boundaries:** Rain and snow share a real outdoor clip that subtracts the enclosed apartment polygon, with the balcony and bedroom window still exposed. Room floors remain dry.
- **Existing work preserved:** Approved normal sofa/beanbag sitting, piano/diagonal animation as present in v0.4.3, existing collision map, all lighting modes, dialogue portrait, touch control customisation and local data identifiers. Piano/diagonal sprites were **not redrawn or represented as fixed** by this targeted update.

## Update-in-place compatibility

- `applicationId`: **`com.thepianist.game`** (unchanged)
- Android `versionName`: **`0.4.4`**
- Android `versionCode`: **`17`**
- Signing keystore: **exact same bytes as v0.4.3**, at `app/pianist-prototype-signing.jks` with the existing Gradle `debug.signingConfig`.
- Touch-control and sound keys stay **`thepianist.controls.v1`** and **`thepianist.sound.v1`**. No localStorage migration or deletion.

**Back up game data first. Install the generated APK over the existing app without uninstalling it.** If Android reports a signing mismatch, stop and do not uninstall: the existing APK may have been signed through a different build path.

## Testing and constraints

- Parsed game JavaScript with Node `--check`.
- Browser-rendered the actual HTML, JS and game assets from this source, covering balcony, apartment, rain, sofa sitting, piano, walking and beanbag.
- Exercised the actual interaction menu to ensure Sofa no longer offers reclining and the Bed still does.
- Loaded each of the five lighting plates and cycled seven weather modes; verified bedroom/bathroom and balcony collision sample points, pause/resume, no browser JS exceptions, and keystore unchanged.
- **Native APK compilation/installation could not be performed in this environment** (no Android SDK/Gradle runtime). The GitHub Actions build and phone installation are still needed for that final verification.

No story/dialogue content was authored or changed. All TEST placeholders are intentional.
