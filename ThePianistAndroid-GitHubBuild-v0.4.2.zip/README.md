# The Pianist v0.4.2 — Android GitHub Actions source ZIP

This is an **in-place update** for package `com.thepianist.game`, `versionName 0.4.2`, `versionCode 14`.
It retains the signing keystore and localStorage settings namespace of v0.4.0.

## Changes

- Human-only, face-up resting sofa illustration fitted within the actual seat, with one bent leg, socks and the open-neck black-shirt styling of the protagonist.
- A piano-specific four-frame two-hand playing sprite, with a physically shifted stool and a sitting anchor aligned to the keyboard.
- Removed the beanbag foreground strip that had cut across the feet. The approved beanbag pose and safe exit remain.
- Refined balcony table/chair collision boxes, railing base boundary and transparent glass foreground treatment; the center sliding door remains the passage.
- Added small independent outdoor leaf drift in wind/storm, without shifting the tree trunks or full canopy.
- Kept five separately painted lighting plates and the full exterior weather masking, plus selective image loading and saved adjustable controls.

## Browser regression checks

A Chromium in-memory run checked game launch, frame rendering, sofa/beanbag/piano sitting and standing up, balcony and bedroom collision points, and rainy rendering. The run reported zero JavaScript page errors. In-browser regression screenshots are supplied separately, not in the ZIP.

## Android build

Upload this ZIP to the GitHub repository root. The existing version-sorting workflow should select it automatically and run `gradle assembleDebug` on the enclosed Android project. Do not uninstall the previous app to install the new APK; back up game data first.

**Test limitation:** An Android SDK/Gradle compile and physical phone installation were not available in the present runtime. Verify launch and in-place installation from the GitHub Actions APK before replacing your working build.


## 0.4.2 unified courtyard

All outdoor views now use the same world-positioned courtyard image. The bedroom window is a real cut-out in the apartment layer; it no longer pastes in a courtyard screenshot from unrelated coordinates. Window frames and reflections are separate. Tightened bedroom and bathroom barriers, slimmed the collision outside the bathroom, revised balcony navigation, and preserved save data and signing key. Character poses use the approved sprite artwork and consistent proportion.
