# The Pianist 0.4.2: QA and installation

Keep the APK installed and retain local storage. Build with the existing GitHub Actions workflow.

Version name 0.4.2 / code 15; applicationId com.thepianist.game; prototype keystore preserved byte for byte.

This build replaces the detached bedroom-window courtyard sample with a window opening onto the shared world-positioned courtyard, adjusts outdoor art beneath that opening, and keeps one active lighting palette loaded. Changes include a narrower collision rectangle beside the bathroom, longer bedroom dividing wall, balcony glass-base and front-of-table clearance changes, unified diagonal frames with waist-seam repair, corrected beanbag feet, more compact original-character sofa recline, and the natural right-facing seated pianist with no duplicated hands.

Browser QA included: launch, all five lighting modes, bedroom window in day and night, rainy weather, sofa sit/lie, piano sit, beanbag sit and getting up, wall geometry, balcony doorway/glass/table clearance. No JavaScript page errors were reported. No native Android APK was compiled or installed in this environment.

The build intentionally leaves existing story TEST dialogue unaltered.
