# The Pianist v0.3.5 — atmosphere and movement test build

This Android source ZIP is compatible with the existing GitHub Actions Gradle 8.9/Java 17 `assembleDebug` workflow. Extract it as an Android project. It preserves the **approved apartment scene, portrait and dialogue-panel visual styling**, the app ID `com.thepianist.game`, and the existing signing keystore. No story or author-written dialogue was invented.

## Updated

- Distinct pre-rendered sunrise/morning/afternoon/sunset **unlit lamp** colour treatments, and a separate night treatment with localized warm lamp glows. Manual time selection at the top right, animated 2.3-second transitions.
- Seven manually selectable outdoor conditions (sunny, cloudy, foggy, rainy, snowy, storm, windy). Outdoor rain/snow particles, storm flashes, fog and small environmental movement. A weather-sound toggle is provided but off by default.
- A **restrained leafy courtyard** beyond the balcony. The camera smoothly lifts while walking towards the balcony; room artwork remains its original size rather than shrinking the flat to make room for the exterior.
- Eight-direction movement and a larger protagonist; composite 3/4 diagonal frames are derived from the approved original character-sheet art, with dedicated side neutral idle poses. These diagonal frames are still prototype composites, not hand-drawn production-quality frames.
- Feet-sized collision radius, tightened object detection and connected bedroom/bathroom/balcony doorways. Passage beside the sofa and coffee table was widened.
- Sofa and bed Sit/Lie Down interaction choices; balcony chair, beanbag, piano sitting; partial character-to-furniture layering, 0.7s pose transitions, stand on movement or INTERACT. Some poses remain intentionally prototype composites, especially lying on the sofa.
- Entry/bath/bedroom vicinity-driven door-swing effects, balcony string light flicker at night, low-key plant swaying and sunlit dust motes.
- Two old floor anomalies retouched with nearby wooden plank textures.
- Approved dialogue portrait panel unchanged, with test-only labels and extra compact buttons inside the same frame for selecting actions.

## Notes and outstanding polish

This is a test build, not the fully finished art pass. The daytime lamp details are retouched approximations over originally baked-lit art; more bespoke lamp/glow layering is needed for final quality. Diagonal sprite directions are composited from the approved cardinal frames; the dedicated diagonal frames are not yet independently hand-drawn. Resting sprites are early prototypes and do not yet show a full physically animated frame-by-frame sitting-down movement. Door leaves are programmatic animated overlays, not individually repainted furniture art. Courtyard is visible most clearly near the balcony; small stylized trees/roofs are intentionally unobtrusive. Weather sound uses soft procedural noise, not recorded sound assets. Collision testing was carried out at a route level in a browser, not on-device.

## Installation/build/signing

- Android applicationId: `com.thepianist.game`
- versionCode: **8**; versionName: **0.3.5**
- Debug build uses the existing `app/pianist-prototype-signing.jks` through the existing `pianistPrototype` signingConfig.
- The existing app can update in place only if the *installed APK* certificate matches this keystore certificate. Before updating, back up any local app data. Never uninstall the old app just to install the update without a backup.
- The ZIP itself and JavaScript were checked. APK compilation and on-device behaviour were not verified in this environment.

Source data is mirrored under `/game` and `app/src/main/assets`. All runtime assets must be present under `app/src/main/assets` in the Android APK.
