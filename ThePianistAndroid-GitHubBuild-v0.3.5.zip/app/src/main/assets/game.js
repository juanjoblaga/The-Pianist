(()=>{'use strict';
// The Pianist v0.3.5 — apartment prototype. Story and dialogue remain player-authored.
const W=1536,H=1024,canvas=document.querySelector('#game'),ctx=canvas.getContext('2d',{alpha:false});
canvas.width=W;canvas.height=H;ctx.imageSmoothingEnabled=true;
const files={};for(const name of ['walk','sit','courtyard','light_sunrise','light_morning','light_afternoon','light_sunset','light_night']){
 const img=new Image();img.src=name+'.'+(name==='walk'||name==='sit'||name==='courtyard'?'png':'jpg');files[name]=img;
}
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const player={x:730,y:570,dir:'down',moving:false,phase:0,pose:null,transition:null};
const keyState=new Set();let joy={x:0,y:0},last=0,time=0,cameraY=0,stormFlash=0,stormNext=18,toastTimer;
let lightMode='afternoon',lastLight='afternoon',lightAmount=1;
let weather='sunny',lastWeather='sunny',weatherBlend=1;
const modes=['sunrise','morning','afternoon','sunset','night'];
const weatherModes=['sunny','cloudy','foggy','rainy','snowy','storm','windy'];
const modeLabels={sunrise:'Sunrise',morning:'Morning',afternoon:'Afternoon',sunset:'Sunset',night:'Night'};
const weatherLabels={sunny:'Sunny',cloudy:'Cloudy',foggy:'Foggy',rainy:'Rainy',snowy:'Snowy',storm:'Storm',windy:'Windy'};
const lighting=$('#lighting'),lightMenu=$('#lightmenu'),weatherButton=$('#weather'),weatherMenu=$('#weathermenu');
const dialogue=$('#dialogue'),dlgText=$('#dialoguetext'),choicePanel=$('#dialoguechoices');
let dialogueFull='',dialogueStart=0,dialogueDuration=0,activeOptions=[];
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const ease=x=>x*x*(3-2*x);
function setLighting(mode){if(!modes.includes(mode))return;lastLight=lightMode;lightMode=mode;lightAmount=0;lightMenu.hidden=true;weatherMenu.hidden=true;lighting.textContent=({sunrise:'◒',morning:'☼',afternoon:'☀',sunset:'◕',night:'☾'})[mode];$$('[data-light]').forEach(b=>b.classList.toggle('selected',b.dataset.light===mode));}
function setWeather(mode){if(!weatherModes.includes(mode))return;lastWeather=weather;weather=mode;weatherBlend=0;weatherMenu.hidden=true;lightMenu.hidden=true;weatherButton.textContent=({sunny:'☀',cloudy:'☁',foggy:'≋',rainy:'☂',snowy:'❄',storm:'ϟ',windy:'〰'})[mode];$$('[data-weather]').forEach(b=>b.classList.toggle('selected',b.dataset.weather===mode));}
lighting.addEventListener('click',()=>{lightMenu.hidden=!lightMenu.hidden;weatherMenu.hidden=true});
weatherButton.addEventListener('click',()=>{weatherMenu.hidden=!weatherMenu.hidden;lightMenu.hidden=true});
$$('[data-light]').forEach(b=>b.addEventListener('click',()=>setLighting(b.dataset.light)));
$$('[data-weather]').forEach(b=>b.addEventListener('click',()=>setWeather(b.dataset.weather)));
function notice(s){const t=$('#toast');t.textContent=s;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),1400)}
// The existing dialogue artwork, placement, borders, typography and approved portrait are unchanged.
function showDialogue(s,options=[]){resetJoystick();activeOptions=options;dialogueFull='[TEST] '+s+' — dialogue to be written later.';dialogueDuration=dialogueFull.length*23;dialogueStart=performance.now();dlgText.textContent='';choicePanel.replaceChildren();for(const opt of options){const b=document.createElement('button');b.type='button';b.textContent=opt.label;b.addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();hideDialogue();opt.action()});choicePanel.appendChild(b)}dialogue.hidden=false}
function hideDialogue(){dialogue.hidden=true;activeOptions=[]}
dialogue.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;e.preventDefault();if(dlgText.textContent!==dialogueFull){dlgText.textContent=dialogueFull;return}if(activeOptions.length===0)hideDialogue()});
// Navigable geometry: a 9-pixel foot-radius permits slim clearance beside furniture.
// Full sprite is VISUAL, only the foot position is solid. Zones connect through actual doors.
const rooms=[
 [235,221,965,872],  // open-plan apartment (no artificial narrow corridor)
 [223,62,831,229],   // balcony deck
 [582,170,832,269],   // glass-door threshold, continuous route around sofa
 [908,435,1040,611],// bedroom doorway
 [920,165,1356,618],// bedroom
 [929,725,1053,845],// bathroom entrance
 [1001,640,1357,870] // bathroom
];
const solids=[
 [275,229,581,338], [273,308,380,419],// sectional sofa long + short portions
 [431,380,551,446],                 // coffee table (now a real navigable gap)
 [246,294,280,553],                 // wall shelf
 [383,527,580,667],                 // dining table plus chair footprint
 [745,245,873,490],                 // piano
 [238,556,281,824], [241,765,634,875], // kitchen counters and refrigerator
 [643,762,690,876],                 // intercom console
 [993,224,1215,555], [1285,323,1357,567], [1219,223,1321,326], // bedroom
 [1097,707,1175,788], [1189,714,1268,823], [1278,650,1355,868],// bathroom
 [349,92,504,164], [720,82,810,176], // balcony chair/beanbag
 [829,119,922,433], // solid dividing wall above bedroom doorway
 [920,618,1000,723] // wall separating bedroom from bathroom
];
// Feet anchored to floor; narrow enough to approach walls, never walk on walls.
const R=9;
const inRoom=(x,y)=>rooms.some(([a,b,c,d])=>x>=a+R&&x<=c-R&&y>=b+R&&y<=d-R);
const overlap=(x,y,b)=>x+R>b[0]&&x-R<b[2]&&y+R>b[1]&&y-R<b[3];
function passable(x,y){return inRoom(x,y)&&!solids.some(b=>overlap(x,y,b))}
function distanceToRect(x,y,b){const ax=clamp(x,b[0],b[2]),ay=clamp(y,b[1],b[3]);return [Math.hypot(ax-x,ay-y),ax-x,ay-y]}
const vector={down:[0,1],up:[0,-1],left:[-1,0],right:[1,0], 'down-left':[-.707,.707], 'down-right':[.707,.707],'up-left':[-.707,-.707],'up-right':[.707,-.707]};
const objects=[
 {id:'piano',name:'Piano',rect:[744,232,870,491],reach:67,poses:['sit']},
 {id:'sofa',name:'Sofa',rect:[280,229,581,415],reach:59,poses:['sit','lie']},
 {id:'table',name:'Coffee table',rect:[431,369,554,449],reach:47},
 {id:'dining',name:'Dining table',rect:[383,515,580,680],reach:54},
 {id:'kitchen',name:'Kitchen',rect:[235,553,642,870],reach:42},
 {id:'bed',name:'Bed',rect:[990,220,1216,557],reach:57,poses:['sit','lie']},
 {id:'wardrobe',name:'Wardrobe',rect:[1285,322,1356,568],reach:50},
 {id:'sink',name:'Bathroom sink',rect:[1092,705,1173,790],reach:45},
 {id:'bath',name:'Bath',rect:[1277,653,1358,868],reach:52},
 {id:'balchair',name:'Balcony chair',rect:[430,82,507,169],reach:54,poses:['sit']},
 {id:'beanbag',name:'Balcony beanbag',rect:[719,80,811,174],reach:55,poses:['sit']},
 {id:'console',name:'Intercom',rect:[640,705,694,869],reach:49},
 {id:'frontdoor',name:'Front door',rect:[707,858,851,987],reach:54}
];
function nearest(){let best=null,dBest=Infinity;const [fx,fy]=vector[player.dir];for(const obj of objects){const [dist,dx,dy]=distanceToRect(player.x,player.y,obj.rect);if(dist>obj.reach)continue;let dot=(dx*fx+dy*fy)/Math.max(dist,.001);if(dist>19&&dot<.08)continue;if(dist<dBest){best=obj;dBest=dist}}return best}
const furniture={
 sofa:{sit:{x:453,y:325,face:'down',exit:{x:470,y:363}},lie:{x:464,y:302,face:'right',exit:{x:466,y:363}}},
 bed:{sit:{x:1103,y:517,face:'down',exit:{x:1103,y:583}},lie:{x:1104,y:315,face:'up',exit:{x:1103,y:581}}},
 balchair:{sit:{x:470,y:135,face:'down',exit:{x:522,y:157}}},
 beanbag:{sit:{x:761,y:134,face:'down',exit:{x:692,y:151}}},
 piano:{sit:{x:741,y:421,face:'right',exit:{x:704,y:425}}}
};
function changePose(id,type){const data=furniture[id]?.[type];if(!data)return;const fromX=player.x,fromY=player.y;const approach=data.exit;
 // Reach condition enforced by nearest(); move towards a nearby safe approach point.
 player.transition={kind:'enter',id,type,t:0,fromX,fromY,toX:data.x,toY:data.y,exit:approach,face:data.face};
 player.moving=false;player.phase=0;resetJoystick();}
function stand(){const old=player.pose;if(!old)return;player.transition={kind:'leave',id:old.id,type:old.type,t:0,fromX:player.x,fromY:player.y,toX:old.exit.x,toY:old.exit.y,exit:old.exit,face:old.face};player.pose=null}
function interact(){if(!dialogue.hidden){if(dlgText.textContent!==dialogueFull)dlgText.textContent=dialogueFull;else if(!activeOptions.length)hideDialogue();return}
 if(player.transition)return;if(player.pose){stand();return}const obj=nearest();if(!obj){notice('Move closer and face an object');return}
 if(obj.poses){const opts=obj.poses.map(type=>({label:type==='sit'?(obj.id==='bed'?'Sit on bed':'Sit down'):'Lie down',action:()=>changePose(obj.id,type)}));
 opts.push({label:'Examine',action:()=>showDialogue(obj.name)});showDialogue(obj.name,opts);
 }else showDialogue(obj.name);
}
// Small variations only when crossing doors; visible door panels hinge/swing with easing.
const doors=[
 {id:'bedroom',x:918,y:503,orientation:'vertical',radius:82},
 {id:'bathroom',x:995,y:775,orientation:'vertical',radius:70},
 {id:'entrance',x:752,y:883,orientation:'horizontal',radius:82}
];
const doorState={bedroom:0,bathroom:0,entrance:0};
function drawDoor(d,t){const s=doorState[d.id];if(s<.025)return;ctx.save();ctx.translate(d.x,d.y);ctx.globalAlpha=.76*s;
 if(d.orientation==='vertical'){
   ctx.rotate((-s*.85)*(d.id==='bedroom'?1:-1));ctx.fillStyle='#805635';ctx.fillRect(-3,-45,10,90);ctx.strokeStyle='#c3945e';ctx.lineWidth=3;ctx.strokeRect(-3,-45,10,90);
   ctx.fillStyle='#dfc18a';ctx.fillRect(3,-4,4,4);
 }else{
   ctx.rotate(.8*s);ctx.fillStyle='#77523a';ctx.fillRect(-29,-4,60,13);ctx.strokeStyle='#c39961';ctx.lineWidth=3;ctx.strokeRect(-29,-4,60,13);
 }ctx.restore()}
function updateDoors(dt){for(const d of doors){const dx=player.x-d.x,dy=player.y-d.y;let inRange=Math.hypot(dx,dy)<d.radius;const to=(inRange&&!player.pose)||player.transition?.id===d.id?1:0;doorState[d.id]+=(to-doorState[d.id])*Math.min(1,dt*3.8)}}
// Stable deterministic particle seeds: arrays are tiny and reuse the same objects.
const rng=(n)=>{let v=Math.sin(n*111.371+23.77)*43758.5453;return v-Math.floor(v)};
const particles=Array.from({length:135},(_,i)=>({x:rng(i*6+1),y:rng(i*6+2),speed:.5+rng(i*6+3)*1.35,size:.9+rng(i*6+4)*1.6,seed:rng(i*6+5)*9}));
const dust=Array.from({length:20},(_,i)=>({x:340+rng(i+1)*455,y:260+rng(i+31)*375,phase:rng(i+92)*6.28}));
let ambientOn=false,audioContext=null,audioNode=null;
function toggleSound(){ambientOn=!ambientOn;$('#sound').textContent=ambientOn?'Sound on':'Sound off';if(!ambientOn){if(audioNode)audioNode.gain.value=0;return}
 try{if(!audioContext){audioContext=new (window.AudioContext||window.webkitAudioContext)();const count=audioContext.sampleRate*2;const buf=audioContext.createBuffer(1,count,audioContext.sampleRate),a=buf.getChannelData(0);let prev=0;for(let i=0;i<count;i++){const n=(Math.random()*2-1);prev=.97*prev+.03*n;a[i]=prev*3}const src=audioContext.createBufferSource();src.buffer=buf;src.loop=true;const low=audioContext.createBiquadFilter();low.type='lowpass';low.frequency.value=weather==='storm'?1250:750;audioNode=audioContext.createGain();audioNode.gain.value=0;src.connect(low).connect(audioNode).connect(audioContext.destination);src.start()}audioContext.resume()}
 catch(e){ambientOn=false;$('#sound').textContent='Sound unavailable'}
}
$('#sound').addEventListener('click',toggleSound);
function updateAmbient(){if(!audioNode)return;const gain=ambientOn?(weather==='rainy'?.038:weather==='storm'?.055:weather==='windy'?.023:weather==='snowy'?.008:0):0;audioNode.gain.setTargetAtTime(gain,audioContext.currentTime,.18)}
// All drawing happens in WORLD coordinates, translated by the vertical look-up camera.
function drawWorldImage(img,opacity=1){if(!img.complete||!img.naturalWidth)return;ctx.save();ctx.globalAlpha=opacity;ctx.drawImage(img,0,0,W,H);ctx.restore()}
function drawCourtyard(){const img=files.courtyard;if(img.complete&&img.naturalWidth){ctx.save();ctx.beginPath();ctx.rect(222,-250,617,335);ctx.clip();ctx.drawImage(img,0,-198,W,290);ctx.restore()}
 // tiny atmospheric distant windows twinkle at night. No skyline perspective change.
 if(lightMode==='night'){
   ctx.save();for(let i=0;i<9;i++){const x=91+i*147,y=-205+(i%3)*17;ctx.fillStyle=`rgba(255,205,137,${.10+.1*(.5+.5*Math.sin(time*.43+i))})`;ctx.fillRect(x,y,12,7)}ctx.restore()}
}
function drawBase(){const a=files['light_'+lastLight],b=files['light_'+lightMode];if(lightAmount<1&&lastLight!==lightMode){drawWorldImage(a,1);drawWorldImage(b,ease(lightAmount))}else drawWorldImage(b)}
// Time-dependent indoor illumination. Day plates have unlit sources;
// night plate retains lamps; localized glows are additive with nearby furniture.
function glow(x,y,r,alpha,color='255,195,114'){
 const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${color},${alpha})`);g.addColorStop(.3,`rgba(${color},${alpha*.42})`);g.addColorStop(1,`rgba(${color},0)`);ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)
}
function timeLight(){const night=lightMode==='night'?ease(lightAmount):lastLight==='night'?1-ease(lightAmount):0;
 if(night>0){ctx.fillStyle=`rgba(11,23,54,${.42*night})`;ctx.fillRect(0,0,W,H);
   ctx.save();ctx.globalCompositeOperation='screen';
   glow(308,270,168,.44*night);glow(852,356,96,.32*night);glow(1248,249,110,.45*night);
   // bathroom deliberately darker at night until a separate room-light switch exists
   for(const [x,y] of [[332,66],[407,51],[480,78],[555,70],[611,95],[670,81],[786,62]])glow(x,y,31,(.30+.05*Math.sin(time*1.7+x)) * night);
   ctx.restore()}
}
function outdoorTint(){const cloud=weather==='cloudy'?.14:weather==='foggy'?.16:weather==='rainy'?.16:weather==='storm'?.25:weather==='snowy'?.09:0;
 if(!cloud)return;ctx.fillStyle=`rgba(33,48,69,${cloud})`;ctx.fillRect(0,-260,W,500)}
function drawWeather(){// Explicit clipping keeps particles OUTSIDE the living room.
 const hasRain=weather==='rainy'||weather==='storm';const snow=weather==='snowy';const wind=weather==='windy'||weather==='storm';
 if(weather==='foggy'){ctx.fillStyle='rgba(194,207,205,.18)';ctx.fillRect(0,-256,W,305);ctx.fillStyle='rgba(204,215,218,.12)';ctx.fillRect(208,50,630,129)}
 if(weather==='cloudy'||hasRain||snow){ctx.fillStyle=`rgba(59,78,95,${hasRain?.11:.065})`;ctx.fillRect(0,-252,W,445)}
 if(!hasRain&&!snow&&!wind)return;
 ctx.save();ctx.beginPath();ctx.rect(0,-256,W,295);ctx.rect(219,60,613,111);ctx.clip();
 const number=snow?92:hasRain?120:28;
 for(let i=0;i<number;i++){
   const p=particles[i],speed=snow?36+p.speed*14:hasRain?185+p.speed*106:75+p.speed*50;
   const y=((p.y*525+time*speed)%525)-260;
   const x=((p.x*1660+time*(wind?54:hasRain?-36:28)+1660)%1660)-65;
   if(snow){ctx.fillStyle=`rgba(241,247,253,${.6+.3*rng(i+10)})`;ctx.beginPath();ctx.arc(x+Math.sin(time+i)*3,y,p.size*1.4,0,6.29);ctx.fill()}
   else if(hasRain){ctx.strokeStyle='rgba(157,201,230,.53)';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-(weather==='storm'?12:6),y+15);ctx.stroke()}
   else{ctx.fillStyle='rgba(192,201,181,.28)';ctx.fillRect(x,y,8,2)}
 }
 ctx.restore();
 if(hasRain){ctx.save();ctx.strokeStyle='rgba(196,217,231,.17)';ctx.lineWidth=1.5;for(let i=0;i<13;i++){const x=230+rng(i*3+5)*580,y=155+rng(i*3+16)*12;ctx.beginPath();ctx.ellipse(x,y,5+3*Math.sin(time*4+i),1.8,0,0,6.28);ctx.stroke()}ctx.restore()}
 if(snow){ctx.fillStyle='rgba(221,232,237,.64)';ctx.fillRect(235,172,595,4)}
}
function animatedPlants(){const windy=weather==='windy'||weather==='storm'?1:weather==='rainy'?.35:.11;
 ctx.save();for(const [x,y,len] of [[268,112,21],[217,260,15],[831,265,11],[1347,570,14]]){
   const sway=Math.sin(time*(windy?2.4:1.1)+x)*windy*3;ctx.strokeStyle='rgba(72,113,64,.8)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y+len);ctx.quadraticCurveTo(x+sway-5,y+3,x+sway,y);ctx.stroke();ctx.fillStyle='#698250';ctx.beginPath();ctx.ellipse(x+sway,y-1,7,3,sway*.02,0,6.28);ctx.fill()
 }ctx.restore();}
function ambientDust(){if(lightMode==='night'||weather==='storm'||weather==='rainy')return;ctx.save();for(const d of dust){const drift=Math.sin(time*.42+d.phase)*14;ctx.globalAlpha=.17+.12*Math.sin(time*.7+d.phase);ctx.fillStyle='#fff7d0';ctx.fillRect(d.x+drift,d.y+Math.cos(time*.37+d.phase)*5,2,2)}ctx.restore()}
// Diagonal atlas is separately prepared from the approved original sprite design.
const spriteRow={down:0,left:1,right:2,up:3,'down-left':4,'down-right':5,'up-left':6,'up-right':7};
function drawWalking(x,y,dir,moving,phase,opacity=1,scale=1){let img=files.walk;if(!img.complete||!img.naturalWidth)return;
 const row=spriteRow[dir]??0,frame=moving?Math.floor(phase*8)%4:0;
 // Eight rows of 80x112 sprite frames, with all directions having a neutral idle frame.
 ctx.save();ctx.globalAlpha=opacity;ctx.imageSmoothingEnabled=false;
 const fw=101*scale,fh=143*scale;ctx.drawImage(img,frame*80,row*112,80,112,x-fw/2,y-fh,fw,fh);
 ctx.restore();ctx.imageSmoothingEnabled=true}
function drawSitting(x,y,face,phase,opacity=1,scale=.85,trimStool=false){const img=files.sit;if(!img.complete||!img.naturalWidth)return;const index=face==='right'?1:face==='left'?2:face==='up'?3:0;
 ctx.save();ctx.globalAlpha=opacity;ctx.imageSmoothingEnabled=false;
 const w=104*scale,sourceH=trimStool?112:170,h=139*scale*(sourceH/170);const bob=Math.sin(time*1.7)*.65;
 ctx.drawImage(img,index*128,0,128,sourceH,x-w/2,y-h+bob,w,h);
 ctx.restore();ctx.imageSmoothingEnabled=true}
function drawReclining(p){ // Carefully composed sideways pose, with approved sprite pixels.
 const id=p.id;if(id==='bed'){
   // Head rests on pillow. Upper body disappears under blue bedcover foreground.
   ctx.save();ctx.imageSmoothingEnabled=false;
   const img=files.walk;const fw=96,fh=135;
   if(img.complete&&img.naturalWidth)ctx.drawImage(img,0,0,80,61,p.x-fw/2,p.y-70,fw,68);
   ctx.restore();return;
 }
 const img=files.sit;if(!img.complete||!img.naturalWidth)return;
 ctx.save();ctx.translate(p.x,p.y-30);ctx.rotate(-Math.PI*.48);ctx.globalAlpha=.96;ctx.imageSmoothingEnabled=false;
 const w=92,h=140;ctx.drawImage(img,128,0,128,170,-w/2,-h*.72,w,h);
 ctx.restore();ctx.imageSmoothingEnabled=true;
}
function renderRest(p){if(p.type==='sit'){drawSitting(p.x,p.y,p.face,0,1,p.id==='beanbag'?.75:p.id==='balchair'?.70:.85,p.id==='sofa'||p.id==='beanbag')}else drawReclining(p);
 // Seat front lip and duvet drawn above legs: character becomes part of furniture.
 if(p.id==='bed'){
   const img=files['light_'+lightMode];if(img.complete&&img.naturalWidth){ctx.save();ctx.globalAlpha=.97;
      if(p.type==='lie')ctx.drawImage(img,994,334,217,186,994,334,217,186);
      else ctx.drawImage(img,1002,514,209,38,1002,514,209,38);
      ctx.restore()}
 }
 if(p.id==='sofa'){
   const img=files['light_'+lightMode];if(img.complete&&img.naturalWidth){ctx.save();ctx.globalAlpha=.93;
      if(p.type==='lie')ctx.drawImage(img,282,335,298,15,282,335,298,15);
      else ctx.drawImage(img,300,332,279,17,300,332,279,17);
      ctx.restore()}
 }
 if(p.id==='beanbag'){
   ctx.save();ctx.strokeStyle='rgba(15,20,32,.42)';ctx.lineWidth=4;ctx.beginPath();ctx.ellipse(762,136,44,29,0,0,6.28);ctx.stroke();ctx.restore()
 }
}
function drawPlayer(){const t=player.transition;
 if(t){const f=ease(clamp(t.t/0.7,0,1));const x=t.fromX+(t.toX-t.fromX)*f,y=t.fromY+(t.toY-t.fromY)*f;
   if(t.kind==='enter'){
      const seated=Math.max(0,clamp((f-.45)/.55,0,1));drawShadow(x,y);drawWalking(x,y,t.face,false,0,1-seated);if(seated>0){ctx.save();ctx.globalAlpha=seated;renderRest({id:t.id,type:t.type,x:t.toX,y:t.toY,face:t.face});ctx.restore()}
   }else{
      const standing=clamp(f*2,0,1);drawShadow(x,y);drawWalking(x,y,t.face,false,0,standing);if(standing<1){ctx.save();ctx.globalAlpha=1-standing;renderRest({id:t.id,type:t.type,x:t.fromX,y:t.fromY,face:t.face});ctx.restore()}
   }return;
 }
 if(player.pose){renderRest(player.pose);return}
 drawShadow(player.x,player.y);drawWalking(player.x,player.y,player.dir,player.moving,player.phase);
}
function drawShadow(x,y){ctx.save();ctx.fillStyle='rgba(19,24,28,.22)';ctx.beginPath();ctx.ellipse(x,y-3,19,6,0,0,Math.PI*2);ctx.fill();ctx.restore()}
function lightingOnSprite(){if(lightMode==='night'){
  const dx=player.x-307,dy=player.y-270,near=clamp(1-Math.hypot(dx,dy)/240,0,1);
  const dx2=player.x-1248,dy2=player.y-249,near2=clamp(1-Math.hypot(dx2,dy2)/170,0,1);
  const bright=Math.max(near,near2);if(bright>.01)glow(player.x,player.y-55,40,.075*bright);
 }}
function draw(){ctx.fillStyle='#111720';ctx.fillRect(0,0,W,H);ctx.save();ctx.translate(0,cameraY);
 // Outdoors lives BEHIND the original approved apartment at world y < 0.
 drawCourtyard();outdoorTint();
 // See the courtyard only where original image had empty sky margin at its top;
 // the user-approved furniture and walls remain pixel-for-pixel untouched.
 drawBase();
 // Balcony reveal comes from gentle camera look-up; never paste a band over the flat.
 ambientDust();animatedPlants();drawWeather();updateAmbient();
 timeLight();
 for(const d of doors)drawDoor(d,time);
 drawPlayer();lightingOnSprite();
 if(stormFlash>0){ctx.fillStyle=`rgba(211,224,255,${stormFlash*.6})`;ctx.fillRect(0,-260,W,1270)}
 ctx.restore();}
function tick(ts){const dt=clamp((ts-last)/1000||0,0,.041);last=ts;time+=dt;
 lightAmount=clamp(lightAmount+dt/2.3,0,1);weatherBlend=clamp(weatherBlend+dt/1.4,0,1);
 stormFlash=Math.max(0,stormFlash-dt*3.0);if(weather==='storm'&&time>stormNext){stormFlash=1;stormNext=time+6+rng(Math.floor(time))*12}
 let vx=joy.x,vy=joy.y;
 if(keyState.has('ArrowLeft')||keyState.has('a'))vx--;
 if(keyState.has('ArrowRight')||keyState.has('d'))vx++;
 if(keyState.has('ArrowUp')||keyState.has('w'))vy--;
 if(keyState.has('ArrowDown')||keyState.has('s'))vy++;
 if(!dialogue.hidden||!$('#modal').hidden||player.transition){vx=0;vy=0}
 const mag=Math.hypot(vx,vy);if(player.pose&&mag>.18){stand();vx=vy=0}
 if(player.transition){const t=player.transition;t.t+=dt;player.x=t.fromX+(t.toX-t.fromX)*ease(clamp(t.t/.7,0,1));player.y=t.fromY+(t.toY-t.fromY)*ease(clamp(t.t/.7,0,1));
   if(t.t>=.7){if(t.kind==='enter'){player.pose={id:t.id,type:t.type,x:t.toX,y:t.toY,exit:t.exit,face:t.face};player.x=t.toX;player.y=t.toY}
      else{player.x=t.toX;player.y=t.toY;player.dir=t.face}player.transition=null}}
 else if(!player.pose&&mag>.14){vx/=Math.max(1,mag);vy/=Math.max(1,mag);player.moving=true;
   const ax=Math.abs(vx),ay=Math.abs(vy);player.dir=(ax>.33&&ay>.33&&Math.min(ax,ay)/Math.max(ax,ay)>.42)?(vy<0?'up-':'down-')+(vx<0?'left':'right'):(ax>ay?(vx<0?'left':'right'):(vy<0?'up':'down'));
   const speed=190;const n=Math.ceil(speed*dt/3);for(let i=0;i<n;i++){const x=player.x+vx*speed*dt/n,y=player.y+vy*speed*dt/n;
     if(passable(x,player.y))player.x=x;if(passable(player.x,y))player.y=y}
   player.phase+=dt;
 }else{player.moving=false;player.phase=0}
 updateDoors(dt);
 // When near balcony, gently lift camera; leave flat at full original scale.
 const target=player.y<245?clamp((245-player.y)/175,0,1)*120:0;
 cameraY+=(target-cameraY)*Math.min(1,dt*3.2);
 if(!dialogue.hidden){const chars=clamp(Math.floor((ts-dialogueStart)/23),0,dialogueFull.length);if(dlgText.textContent.length<chars)dlgText.textContent=dialogueFull.slice(0,chars)}
 draw();requestAnimationFrame(tick)}requestAnimationFrame(tick);
const pad=$('#joystick'),stick=$('#stick');
function movePad(e){const r=pad.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,limit=r.width*.33;let x=e.clientX-cx,y=e.clientY-cy,m=Math.hypot(x,y);if(m>limit){x*=limit/m;y*=limit/m}joy={x:x/limit,y:y/limit};stick.style.left=(50+x/r.width*100)+'%';stick.style.top=(50+y/r.height*100)+'%'}
function resetJoystick(){joy={x:0,y:0};stick.style.left=stick.style.top='50%'}
pad.addEventListener('pointerdown',e=>{e.preventDefault();pad.setPointerCapture(e.pointerId);movePad(e)});
pad.addEventListener('pointermove',e=>{if(pad.hasPointerCapture(e.pointerId))movePad(e)});
pad.addEventListener('pointerup',resetJoystick);pad.addEventListener('pointercancel',resetJoystick);
$('#action').addEventListener('pointerdown',e=>{e.preventDefault();interact()});
window.addEventListener('keydown',e=>{const k=e.key.length===1?e.key.toLowerCase():e.key;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(k))e.preventDefault();keyState.add(k);if((k==='e'||k===' ')&&!e.repeat)interact()});
window.addEventListener('keyup',e=>keyState.delete(e.key.length===1?e.key.toLowerCase():e.key));
window.addEventListener('blur',()=>{keyState.clear();resetJoystick()});
$('#help').onclick=()=>{$('#modal').hidden=false;resetJoystick()};$('#close').onclick=()=>$('#modal').hidden=true;
// Debug-only hooks for screenshot/geometry tests, inert during normal play.
window.__pianistTest={getState:()=>({x:player.x,y:player.y,dir:player.dir,pose:player.pose,lightMode,weather,cameraY}),setPlayer:(x,y,dir)=>{player.x=x;player.y=y;player.dir=dir||player.dir;player.pose=null;player.transition=null},setLighting,setWeather,passable,interact};
})();
