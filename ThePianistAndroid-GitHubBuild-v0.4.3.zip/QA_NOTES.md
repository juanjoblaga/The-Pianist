# v0.4.3 release check

## Validated by automated embedded-asset Chromium page
- Game startup and active canvas renderer (afternoon / night)
- Outdoor rainy rendering, no JavaScript page exceptions
- Sofa lie, piano sit, beanbag sit, and diagonal movement screenshot captures
- Targeted collisions: bathroom open corridor, bathroom upper wall, bathroom outer corner, bedroom rear wall, balcony rear rail, front-of-table clearance, balcony doorway
- Version and keystore consistency

## Device test still required
- Install resulting signed APK over v0.4.2; confirm no signature conflict
- Slow/fast 8-direction joystick animation, especially arm swing
- Piano forearm action at actual gameplay resolution
- Sofa lie in multiple lighting modes; preserve earlier approved sofa/beanbag sitting
- Walk beside bathroom into bedroom, check balcony glass, table/chair clearance and rail
- Rain/snow above balcony, at both sides, below entrance and through bedroom window, but not inside
- Background/resume audio policy, saved layout and no missing assets

This is a test build. It has not been tested on the user's physical Android device.
