# The Pianist — v0.4.3 Android GitHub Actions source

This archive is the **complete Gradle Android project**. Keep the previously installed APK and upload this ZIP to the root of your existing The Pianist GitHub repository, replacing the earlier ZIP there if desired. Run your existing `Build The Pianist APK` Actions workflow. The workflow should select the newest versioned ZIP and build `assembleDebug` using the included prototype keystore.

- `applicationId`: `com.thepianist.game` (unchanged)
- `versionName`: `0.4.3`
- `versionCode`: `16`
- Signing: original prototype keystore preserved without alteration.
- Settings: `thepianist.controls.v1` and `thepianist.sound.v1` storage keys unchanged. Do not uninstall your working app before installing the new APK. Back up your game data first.

## Changes from 0.4.2

- **One courtyard image plane:** The existing 5 urban-world artwork plates now align behind the balcony, bedroom window and all visible exterior sides. No separately cropped balcony-view scene is rendered. The opaque black cap behind the rear balcony railing is removed, while the actual rail/posts remain visible. Front path and planted garden sections now continue the same world plate under the flat.
- **Outdoor weather mask:** Exposed courtyard, balcony, apartment exterior and window areas share outdoor rain/snow; rooms remain excluded from the weather overlay.
- **Character movement:** Four diagonal walking poses for each diagonal direction have additional opposed hand/arm motion and registered feet. Analogue input still controls walking speed. The original standing and neutral idle assets remain untouched.
- **Piano:** Four distinct playing frames move the small forearm/hand pixels above the existing keys without adding another pair of arms. Approved seated pose and stool placement remain.
- **Sofa:** A more compact reclining sprite based on the established original-character art replaces the independent adult-styled artwork; original black clothing retained. Approved sofa sitting and beanbag sitting assets are unchanged.
- **Collision:** Small clearance added beside the bathroom wall toward the bedroom; solid bathroom wall/corner, bedroom back wall, fixed balcony glass and outer railing remain blocked.

## Tests & limitations

Browser renderer tests exercised afternoon and night, sofa, beanbag, piano, walking and rainy exterior. Automated collision assertions covered bathroom wall and clearance, bedroom wall, balcony rail, glass doorway, front-of-table route and rear bedroom wall. Tests reported no JavaScript page exceptions. Sprite sheets were checked for actual frame differences, all image references exist, and ZIP integrity was checked.

**Native Android compilation and installation could not be run here.** A successful browser render does not prove the APK starts on every Android handset. Use the GitHub Actions APK and install over v0.4.2 for physical testing. This release does not add any dialogue or story content.
