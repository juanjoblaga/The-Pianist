(()=>{'use strict';
const canvas=document.querySelector('#game'),ctx=canvas.getContext('2d',{alpha:false});
const W=1536,H=1024;canvas.width=W;canvas.height=H;
const background=new Image(),walking=new Image();background.src='apartment.jpg';walking.src='walk.png';
const player={x:711,y:565,dir:'down',moving:false,phase:0};
const keys=new Set();let joy={x:0,y:0},last=0,noticeTimer;
const toast=document.querySelector('#toast');
const dialogue=document.querySelector('#dialogue'),dialogueText=document.querySelector('#dialoguetext');
const lightMenu=document.querySelector('#lightmenu'),lightButton=document.querySelector('#lighting');
const lightModes=['sunrise','morning','afternoon','sunset','night'];let lightMode='afternoon',lightBlend=1,previousMode='afternoon';
const lightColors={sunrise:[245,165,126,.19,.12],morning:[255,220,164,.09,.03],afternoon:[255,255,255,0,0],sunset:[236,125,72,.26,.21],night:[30,49,101,.43,.50]};
function setLighting(mode){if(!lightColors[mode])return;previousMode=lightMode;lightMode=mode;lightBlend=0;lightMenu.hidden=true;lightButton.textContent=mode==='night'?'☾':mode==='sunset'?'◕':'☀';document.querySelectorAll('[data-light]').forEach(b=>b.classList.toggle('selected',b.dataset.light===mode))}
lightButton.addEventListener('click',()=>lightMenu.hidden=!lightMenu.hidden);
document.querySelectorAll('[data-light]').forEach(b=>b.addEventListener('click',()=>setLighting(b.dataset.light)));
function showDialogue(label){dialogueText.textContent='[TEST INTERACTION] '+label+'. Dialogue to be written later.';dialogue.hidden=false;reset()}
function closeDialogue(){dialogue.hidden=true}
dialogue.addEventListener('pointerdown',e=>{e.preventDefault();closeDialogue()});

// Playable zones. Rooms are connected by two deliberately open passages.
const zones=[
 [237,215,969,901],       // open-plan main apartment
 [904,522,1038,621],      // bedroom threshold (left to right)
 [925,175,1356,617],      // bedroom
 [940,740,1055,833],      // bathroom threshold (left to right)
 [1015,655,1355,864],     // bathroom
 [234,64,824,187],       // balcony
 [305,155,792,250]       // balcony glass doors
];
// Physical furniture and wall collision geometry; only walkable doors are excluded.
const solids=[
 // sofa and living room objects
 [279,224,639,350],[281,315,430,424],[438,354,551,457],
 [255,328,304,545],[384,509,581,673],
 // upright piano, kitchen cabinetry and refrigerator
 [746,215,875,497],[254,551,307,754],[241,763,645,868],
 // bedroom bed and wardrobe; room edges handled by zone geometry
 [994,220,1217,557],[1280,289,1354,542],[1213,210,1320,321],
 // bathroom furniture
 [1090,683,1175,776],[1182,693,1258,796],[1270,655,1353,854],
 // relocated cabinet to left of entrance
 [647,761,698,868],
 // balcony objects
 [362,72,569,167],[720,66,811,175]
];
const objects=[
 {name:'Piano',box:[749,217,879,499],reach:87},
 {name:'Sofa',box:[279,225,638,427],reach:72},
 {name:'Coffee table',box:[435,351,557,459],reach:70},
 {name:'Dining table',box:[382,510,583,675],reach:73},
 {name:'Kitchen',box:[241,554,649,867],reach:68},
 {name:'Bed',box:[994,220,1220,559],reach:72},
 {name:'Wardrobe',box:[1280,285,1354,545],reach:65},
 {name:'Bathroom sink',box:[1092,687,1179,773],reach:65},
 {name:'Bath',box:[1270,655,1353,856],reach:72},
 {name:'Balcony chair',box:[362,72,569,167],reach:76},
 {name:'Balcony beanbag',box:[720,66,811,175],reach:78},
 {name:'Console and intercom',box:[646,709,698,869],reach:70},
 {name:'Front door',box:[714,852,817,955],reach:85}
];
function inside(x,y,r){return zones.some(([a,b,c,d])=>x-r>=a&&x+r<=c&&y-r>=b&&y+r<=d)}
function intersects(x,y,r,box){return x+r>box[0]&&x-r<box[2]&&y+r>box[1]&&y-r<box[3]}
function passable(x,y){const r=12;return inside(x,y,r)&&!solids.some(b=>intersects(x,y,r,b))}
const faceVector=()=>({down:[0,1],up:[0,-1],left:[-1,0],right:[1,0]})[player.dir];
function nearRect(x,y,b){const nx=Math.max(b[0],Math.min(x,b[2])),ny=Math.max(b[1],Math.min(y,b[3]));return [Math.hypot(nx-x,ny-y),nx-x,ny-y]}
function closestObject(){let found=null,best=Infinity;const [fx,fy]=faceVector();for(const o of objects){const [dist,dx,dy]=nearRect(player.x,player.y,o.box);if(dist>o.reach)continue;const facing=dist<22||(dx*fx+dy*fy)/Math.max(1,dist)>0.12;if(!facing)continue;if(dist<best){best=dist;found=o}}return found}
function interact(){if(!dialogue.hidden){closeDialogue();return}const obj=closestObject();if(obj){showDialogue(obj.name);return}toast.textContent='Nothing within reach';toast.classList.add('show');clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>toast.classList.remove('show'),1350)}
function draw(){ctx.fillStyle='#10131a';ctx.fillRect(0,0,W,H);if(background.complete&&background.naturalWidth)ctx.drawImage(background,0,0,W,H);
 ctx.fillStyle='#10151a70';ctx.beginPath();ctx.ellipse(player.x,player.y-2,13,4,0,0,Math.PI*2);ctx.fill();
 if(walking.complete&&walking.naturalWidth){const row={down:0,left:1,right:2,up:3}[player.dir],frame=player.moving?Math.floor(player.phase*8)%4:(player.dir==='left'||player.dir==='right'?2:0);
 ctx.imageSmoothingEnabled=false;ctx.drawImage(walking,frame*80,row*112,80,112,player.x-37,player.y-107,74,107);ctx.imageSmoothingEnabled=true;
 }else{ctx.fillStyle='#d6a47c';ctx.fillRect(player.x-12,player.y-58,24,25);ctx.fillStyle='#26333b';ctx.fillRect(player.x-12,player.y-33,24,31)}
 
 // Time-of-day lighting is applied across the existing artwork and character.
 const from=lightColors[previousMode],to=lightColors[lightMode],mix=(a,b)=>a+(b-a)*lightBlend;
 const r=mix(from[0],to[0]),g=mix(from[1],to[1]),b=mix(from[2],to[2]),alpha=mix(from[3],to[3]),shade=mix(from[4],to[4]);
 ctx.fillStyle=`rgba(${r|0},${g|0},${b|0},${alpha})`;ctx.fillRect(0,0,W,H);
 if(shade){ctx.fillStyle=`rgba(8,17,33,${shade})`;ctx.fillRect(0,0,W,H)}
 if(lightMode==='night'||lightMode==='sunset'||previousMode==='night'){
 const strength=lightMode==='night'?.8:lightMode==='sunset'?.4:0;
 for(const [x,y,radius] of [[351,331,115],[1120,298,105],[740,105,80]]){
 const grad=ctx.createRadialGradient(x,y,3,x,y,radius);grad.addColorStop(0,`rgba(255,199,107,${strength*.25})`);grad.addColorStop(1,'rgba(255,199,107,0)');ctx.fillStyle=grad;ctx.fillRect(x-radius,y-radius,radius*2,radius*2)
 }
 }
}
function tick(t){const dt=Math.min((t-last)/1000||0,.04);last=t;lightBlend=Math.min(1,lightBlend+dt/2.2);let dx=joy.x,dy=joy.y;
 if(keys.has('ArrowLeft')||keys.has('a'))dx--;if(keys.has('ArrowRight')||keys.has('d'))dx++;if(keys.has('ArrowUp')||keys.has('w'))dy--;if(keys.has('ArrowDown')||keys.has('s'))dy++;
 if(!dialogue.hidden){dx=0;dy=0}const mag=Math.hypot(dx,dy);player.moving=mag>.12;
 if(player.moving){dx/=Math.max(1,mag);dy/=Math.max(1,mag);if(Math.abs(dx)>Math.abs(dy)*1.15)player.dir=dx<0?'left':'right';else player.dir=dy<0?'up':'down';const speed=178,stepX=dx*speed*dt,stepY=dy*speed*dt;
 // Substeps stop tunnelling through furniture at low frame rates.
 for(let n=0;n<3;n++){const nx=player.x+stepX/3,ny=player.y+stepY/3;if(passable(nx,player.y))player.x=nx;if(passable(player.x,ny))player.y=ny}
 player.phase+=dt;
 }else player.phase=0;
 draw();requestAnimationFrame(tick)}requestAnimationFrame(tick);
const pad=document.querySelector('#joystick'),stick=document.querySelector('#stick');
function movePad(e){const r=pad.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,lim=r.width*.33;let x=e.clientX-cx,y=e.clientY-cy,m=Math.hypot(x,y);if(m>lim){x*=lim/m;y*=lim/m}joy={x:x/lim,y:y/lim};stick.style.left=(50+x/r.width*100)+'%';stick.style.top=(50+y/r.height*100)+'%'}
function reset(){joy={x:0,y:0};stick.style.left='50%';stick.style.top='50%'}
pad.addEventListener('pointerdown',e=>{e.preventDefault();pad.setPointerCapture(e.pointerId);movePad(e)});
pad.addEventListener('pointermove',e=>{if(pad.hasPointerCapture(e.pointerId))movePad(e)});
pad.addEventListener('pointerup',reset);pad.addEventListener('pointercancel',reset);
document.querySelector('#action').addEventListener('pointerdown',e=>{e.preventDefault();interact()});
window.addEventListener('keydown',e=>{const k=e.key.length===1?e.key.toLowerCase():e.key;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(k))e.preventDefault();keys.add(k);if((k==='e'||k===' ')&&!e.repeat)interact()});
window.addEventListener('keyup',e=>keys.delete(e.key.length===1?e.key.toLowerCase():e.key));
window.addEventListener('blur',()=>{keys.clear();reset()});
document.querySelector('#help').onclick=()=>document.querySelector('#modal').hidden=false;
document.querySelector('#close').onclick=()=>document.querySelector('#modal').hidden=true;
})();
