# The Pianist v0.3.3 — four-direction walking sprite update

Uses the user's approved walking reference sheet (53370.png), extracting distinct down/left/right/up frames, removing checkerboard background and anchoring feet to the floor. Preserves approved apartment, layout, existing icon and keystore. No story content.

Application ID: com.thepianist.game; versionCode: 6; versionName: 0.3.3.

## Signing
Same pianist-prototype-signing.jks and Gradle signingConfig as v0.3.1/v0.3.2. The *APK certificate* must match the installed app to update without uninstalling. Previous uninstall failures may indicate the installed APK was signed differently or a different ZIP was built. Verify with apksigner verify --print-certs. Do not uninstall before backing up data.

## Build
Upload ZIP to private GitHub repository. The existing workflow extracts highest-version matching ZIP; ensure build logs show v0.3.3. APK build not verified here.

Note: the reference sheet is a composited artwork rather than an exportable source sprite atlas; extracted edges may have minor artifacts. The game sprite is scaled to fit the existing apartment; bed proportions remain unchanged.
