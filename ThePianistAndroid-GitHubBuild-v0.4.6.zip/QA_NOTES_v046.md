# The Pianist v0.4.6 — source and browser QA

**Source baseline**: GitHub v0.4.5 Android ZIP, application ID `com.thepianist.game`.

## Implemented
- [x] Six original piano-playing frames from the user-approved 2×3 sheet. Renderer steps through all six; no audio is synthesized.
- [x] Three-frame breathing idle from the approved natural ceiling-facing lying pose; pillow visible when reclining on sofa.
- [x] **Sofa Lie down** restored to dialogue and pose system, horizontally aligned with the upper sofa cushion; **Sit** shifted onto the chaise.
- [x] Sofa lie exit moved to the right-hand open walkway, above the coffee table; sofa sit exits through clear floor at the chaise's edge.
- [x] Bed Lie down uses vertically oriented body with legs clipped under the original duvet, no feet drawn over blankets; original bed pillow visual kept.
- [x] Balcony chair feet moved off the glass railing and back toward the chair.
- [x] Piano sit exit brought within re-interaction range.
- [x] Original characters, scene artwork, approved dialogue, portraits, movement, weather, shower, controls, save keys and original signing key retained.
- [x] VersionName 0.4.6 / versionCode 19, same Android package and signing configuration.

## Browser verification
- [x] Headless Chromium loaded the **actual game HTML, JS, CSS and original PNG/JPG assets**. Images were supplied in-memory due to browser navigation policy; localStorage was supplied via a test-only shim, *not* added to game source.
- [x] Sofa Sit and Lie down selected through the Interact button, stayed in correct pose, stood up and exited on walkable floor.
- [x] Bed Sit and Lie down and Piano Play selected through the UI, stood up and exited on walkable floor.
- [x] All 13 world interactables offered the expected original dialogue/options when approached from passable floor coordinates (including front door, shower and balcony).
- [x] Shower privacy animation and five-second auto-exit completed with exact dialogue `Nice and clean`.
- [x] Five lighting modes and seven weather modes rendered without browser JS errors.
- [x] Controls adjustment worked and correct save value reached localStorage shim.
- [x] 1536×900 and 960×540 landscape viewports rendered; sofa, piano, bed and sitting screenshots manually reviewed.
- [x] Test-reported browser errors: zero. `node --check` passed.

## Requires on-device / GitHub Actions validation
- [ ] GitHub Actions Gradle `assembleDebug` run: Android SDK/Gradle not available locally.
- [ ] Install the resulting signed APK **over** the current app without uninstalling; confirm the existing localStorage and controls remain.
- [ ] Check sofa and piano motion at physical phone scale, especially movement into/out of sofa poses and frame pacing.

Do not uninstall the current app to test the update. Keep the original signing keystore.
