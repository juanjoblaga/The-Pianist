(()=>{'use strict';
// The Pianist v0.3.9 — apartment prototype. Story and dialogue remain player-authored.
const W=1536,H=1024,canvas=document.querySelector('#game'),ctx=canvas.getContext('2d',{alpha:false});
canvas.width=W;canvas.height=H;ctx.imageSmoothingEnabled=true;
// Keep only one fully decoded time-of-day scene in memory. A second scene is
// temporarily retained during a requested transition, then released.
const files=Object.create(null);
const modes=['sunrise','morning','afternoon','sunset','night'];
const modePrefixes=['world','light','frontdoor','bathdoor','trees'];
const persistentAssets=['walk_indoor','idle_indoor','diagonal_indoor','sitting_indoor','beanbag_indoor','sofa_recline_approved','duvet_foreground','balcony_threshold'];
const assetPromises=Object.create(null);
const imageExtension=n=>n.startsWith('world_')||n.startsWith('light_')?'jpg':'png';
function ensureAsset(name){
 if(files[name]&&files[name].complete&&files[name].naturalWidth)return Promise.resolve(files[name]);
 if(assetPromises[name])return assetPromises[name];
 const img=new Image(); img.decoding='async'; files[name]=img;
 const promise=new Promise((resolve,reject)=>{
  img.onload=()=>resolve(img);
  img.onerror=()=>reject(new Error('Missing game artwork: '+name));
  img.src=name+'.'+imageExtension(name);
 });
 assetPromises[name]=promise;
 // Permit retry after a failure, and avoid an unhandled rejection in Android WebView.
 promise.catch(err=>{delete assetPromises[name];delete files[name];
  const el=document.querySelector('#loadStatus');if(el){el.textContent='Could not load '+name+'. Tap to retry.';el.hidden=false;}
  console.error(err);
 });
 return promise;
}
function ensureMode(mode){return Promise.all(modePrefixes.map(p=>ensureAsset(p+'_'+mode)));}
function discardMode(mode){if(!mode||mode===lightMode)return;
 for(const prefix of modePrefixes){const key=prefix+'_'+mode;
  if(files[key]){files[key].onload=null;files[key].onerror=null;delete files[key]};delete assetPromises[key];}
}
let modeToken=0,ready=false,failedStartup=false;
Promise.all([...persistentAssets.map(ensureAsset),ensureMode('afternoon')]).then(()=>{
 ready=true;document.querySelector('#loadStatus')?.remove();
}).catch(e=>{failedStartup=true;console.error('Game startup:',e)});
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const player={x:730,y:570,dir:'down',moving:false,phase:0,pose:null,transition:null};
const keyState=new Set();let joy={x:0,y:0},last=0,time=0,cameraY=0,stormFlash=0,stormNext=18,toastTimer;
player.speed=0;
let lightMode='afternoon',lastLight='afternoon',lightAmount=1;
let weather='sunny',lastWeather='sunny',weatherBlend=1;
let balconyOpening=0;let gamePaused=false;let soundWanted=false;
const weatherModes=['sunny','cloudy','foggy','rainy','snowy','storm','windy'];
const modeLabels={sunrise:'Sunrise',morning:'Morning',afternoon:'Afternoon',sunset:'Sunset',night:'Night'};
const weatherLabels={sunny:'Sunny',cloudy:'Cloudy',foggy:'Foggy',rainy:'Rainy',snowy:'Snowy',storm:'Storm',windy:'Windy'};
const lighting=$('#lighting'),lightMenu=$('#lightmenu'),weatherButton=$('#weather'),weatherMenu=$('#weathermenu');
const dialogue=$('#dialogue'),dlgText=$('#dialoguetext'),choicePanel=$('#dialoguechoices');
let dialogueFull='',dialogueStart=0,dialogueDuration=0,activeOptions=[];
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const ease=x=>x*x*(3-2*x);
function setLighting(mode){
 if(!modes.includes(mode)||mode===lightMode)return;
 const request=++modeToken;
 lightMenu.hidden=true;weatherMenu.hidden=true;
 ensureMode(mode).then(()=>{
  if(request!==modeToken){discardMode(mode);return;}
  // A quick new selection never holds on to the earlier three scene palettes.
  if(lastLight!==lightMode)discardMode(lastLight);
  lastLight=lightMode;lightMode=mode;lightAmount=0;
  lighting.textContent=({sunrise:'◒',morning:'☼',afternoon:'☀',sunset:'◕',night:'☾'})[mode];
  $$('[data-light]').forEach(b=>b.classList.toggle('selected',b.dataset.light===mode));
 }).catch(()=>notice('Unable to load '+mode+' lighting'));
}
function setWeather(mode){if(!weatherModes.includes(mode))return;lastWeather=weather;weather=mode;weatherBlend=0;weatherMenu.hidden=true;lightMenu.hidden=true;weatherButton.textContent=({sunny:'☀',cloudy:'☁',foggy:'≋',rainy:'☂',snowy:'❄',storm:'ϟ',windy:'〰'})[mode];$$('[data-weather]').forEach(b=>b.classList.toggle('selected',b.dataset.weather===mode));}
lighting.addEventListener('click',()=>{lightMenu.hidden=!lightMenu.hidden;weatherMenu.hidden=true});
weatherButton.addEventListener('click',()=>{weatherMenu.hidden=!weatherMenu.hidden;lightMenu.hidden=true});
$$('[data-light]').forEach(b=>b.addEventListener('click',()=>setLighting(b.dataset.light)));
$$('[data-weather]').forEach(b=>b.addEventListener('click',()=>setWeather(b.dataset.weather)));
function notice(s){const t=$('#toast');t.textContent=s;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),1400)}
// The existing dialogue artwork, placement, borders, typography and approved portrait are unchanged.
function showDialogue(s,options=[]){resetJoystick();activeOptions=options;dialogueFull='[TEST] '+s+' — dialogue to be written later.';dialogueDuration=dialogueFull.length*23;dialogueStart=performance.now();dlgText.textContent='';choicePanel.replaceChildren();for(const opt of options){const b=document.createElement('button');b.type='button';b.textContent=opt.label;b.addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();hideDialogue();opt.action()});choicePanel.appendChild(b)}dialogue.hidden=false}
function hideDialogue(){dialogue.hidden=true;activeOptions=[]}
dialogue.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;e.preventDefault();if(dlgText.textContent!==dialogueFull){dlgText.textContent=dialogueFull;return}if(activeOptions.length===0)hideDialogue()});
// Navigable geometry: a 9-pixel foot-radius permits slim clearance beside furniture.
// Full sprite is VISUAL, only the foot position is solid. Zones connect through actual doors.
const rooms=[
 [235,221,965,872],  // open-plan apartment
 [233,122,832,219],   // balcony behind SOLID outer railing
 [586,185,648,267],  // only the sliding-door opening connects indoors and outdoors
 [908,435,1040,611],// bedroom doorway
 [920,165,1356,618],// bedroom
 [929,725,1053,845],// bathroom entrance
 [1001,640,1357,870] // bathroom
];
const solids=[
 [275,229,581,338], [273,308,380,419],// sectional sofa long + short portions
 [431,380,551,446],                 // coffee table (now a real navigable gap)
 [246,294,280,553],                 // wall shelf
 [383,527,580,667],                 // dining table plus chair footprint
 [745,245,873,490],                 // piano
 [238,556,281,824], [241,765,634,875], // kitchen counters and refrigerator
 [643,762,690,876],                 // intercom console
 [993,224,1215,555], [1285,323,1357,567], [1219,223,1321,326], // bedroom
 [1097,707,1175,788], [1189,714,1268,823], [1278,650,1355,868],// bathroom
 [349,92,504,164], [720,82,810,176], // balcony chair/beanbag
 [230,60,838,147], // solid outer railing; feet cannot enter the metal rail or look over it
 [235,175,580,238], [654,175,832,238], // fixed glass panes: only centre sliding door is traversable
 [829,119,922,433], // solid dividing wall above bedroom doorway
 [920,618,1000,723], // wall separating bedroom from bathroom
 [918,166,1358,220] // solid wall behind the bed and along the new window
];
// Feet anchored to floor; narrow enough to approach walls, never walk on walls.
const R=9;
const inRoom=(x,y)=>rooms.some(([a,b,c,d])=>x>=a+R&&x<=c-R&&y>=b+R&&y<=d-R);
const overlap=(x,y,b)=>x+R>b[0]&&x-R<b[2]&&y+R>b[1]&&y-R<b[3];
function passable(x,y){return inRoom(x,y)&&!solids.some(b=>overlap(x,y,b))}
function distanceToRect(x,y,b){const ax=clamp(x,b[0],b[2]),ay=clamp(y,b[1],b[3]);return [Math.hypot(ax-x,ay-y),ax-x,ay-y]}
const vector={down:[0,1],up:[0,-1],left:[-1,0],right:[1,0], 'down-left':[-.707,.707], 'down-right':[.707,.707],'up-left':[-.707,-.707],'up-right':[.707,-.707]};
const objects=[
 {id:'piano',name:'Piano',rect:[744,232,870,491],reach:67,poses:['sit']},
 {id:'sofa',name:'Sofa',rect:[280,229,581,415],reach:59,poses:['sit','lie']},
 {id:'table',name:'Coffee table',rect:[431,369,554,449],reach:47},
 {id:'dining',name:'Dining table',rect:[383,515,580,680],reach:54},
 {id:'kitchen',name:'Kitchen',rect:[235,553,642,870],reach:42},
 {id:'bed',name:'Bed',rect:[990,220,1216,557],reach:57,poses:['sit','lie']},
 {id:'wardrobe',name:'Wardrobe',rect:[1285,322,1356,568],reach:50},
 {id:'sink',name:'Bathroom sink',rect:[1092,705,1173,790],reach:45},
 {id:'bath',name:'Bath',rect:[1277,653,1358,868],reach:52},
 {id:'balchair',name:'Balcony chair',rect:[430,82,507,169],reach:54,poses:['sit']},
 {id:'beanbag',name:'Balcony beanbag',rect:[719,80,811,174],reach:55,poses:['sit']},
 {id:'console',name:'Intercom',rect:[640,705,694,869],reach:49},
 {id:'frontdoor',name:'Front door',rect:[707,858,851,987],reach:54}
];
function nearest(){let best=null,dBest=Infinity;const [fx,fy]=vector[player.dir];for(const obj of objects){const [dist,dx,dy]=distanceToRect(player.x,player.y,obj.rect);if(dist>obj.reach)continue;let dot=(dx*fx+dy*fy)/Math.max(dist,.001);if(dist>19&&dot<.08)continue;if(dist<dBest){best=obj;dBest=dist}}return best}
const furniture={
 sofa:{sit:{x:447,y:342,face:'down',exit:{x:466,y:363}},lie:{x:439,y:305,face:'right',exit:{x:466,y:363}}},
 bed:{sit:{x:1103,y:517,face:'down',exit:{x:1103,y:583}},lie:{x:1104,y:347,face:'up',exit:{x:1103,y:581}}},
 balchair:{sit:{x:470,y:170,face:'left',exit:{x:522,y:157}}},
 beanbag:{sit:{x:761,y:169,face:'down',exit:{x:692,y:151}}},
 piano:{sit:{x:741,y:421,face:'right',exit:{x:704,y:425}}}
};
function changePose(id,type){const data=furniture[id]?.[type];if(!data)return;const fromX=player.x,fromY=player.y;const approach=data.exit;
 // Reach condition enforced by nearest(); move towards a nearby safe approach point.
 player.transition={kind:'enter',id,type,t:0,fromX,fromY,toX:data.x,toY:data.y,exit:approach,face:data.face};
 player.moving=false;player.phase=0;resetJoystick();}
function stand(){const old=player.pose;if(!old)return;player.transition={kind:'leave',id:old.id,type:old.type,t:0,fromX:player.x,fromY:player.y,toX:old.exit.x,toY:old.exit.y,exit:old.exit,face:old.face};player.pose=null}
function interact(){if(!dialogue.hidden){if(dlgText.textContent!==dialogueFull)dlgText.textContent=dialogueFull;else if(!activeOptions.length)hideDialogue();return}
 if(player.transition)return;if(player.pose){stand();return}const obj=nearest();if(!obj){notice('Move closer and face an object');return}
 if(obj.poses){const opts=obj.poses.map(type=>({label:type==='sit'?(obj.id==='bed'?'Sit on bed':'Sit down'):'Lie down',action:()=>changePose(obj.id,type)}));
 opts.push({label:'Examine',action:()=>showDialogue(obj.name)});showDialogue(obj.name,opts);
 }else showDialogue(obj.name);
}
// Small variations only when crossing doors; visible door panels hinge/swing with easing.
// The static bedroom, bathroom and entrance doors belong to the approved art.
// Do not paint a second swinging door OVER their already-painted leaves.
// The balcony slider is a separate, physical opening with no duplicated base leaf.
function drawBalconyDoor(){
  const img=files.balcony_threshold;
  if(img.complete&&img.naturalWidth)ctx.drawImage(img,574,171,89,68);
  const dx=balconyOpening*64;
  ctx.save();ctx.globalAlpha=.93;
  ctx.fillStyle='#546b70';ctx.fillRect(587+dx,179,57,43);
  ctx.fillStyle='rgba(95,135,143,.57)';ctx.fillRect(592+dx,183,47,35);
  ctx.strokeStyle='#c8c1ad';ctx.lineWidth=4;ctx.strokeRect(587+dx,178,57,45);
  ctx.fillStyle='#d5ceb5';ctx.fillRect(594+dx,198,3,9);
  ctx.restore();
}
let bedroomDoorAngle=0,frontDoorMotion=0,bathDoorMotion=0;
function drawPhysicalDoors(){
 const front=files['frontdoor_'+lightMode],bath=files['bathdoor_'+lightMode];
 // Rotations around physically correct hinges; source door artwork was removed from base plate.
 if(front?.complete&&front.naturalWidth){ctx.save();ctx.translate(719,811);
  ctx.rotate(-.28*ease(frontDoorMotion));ctx.drawImage(front,704-719,801-811);ctx.restore();}
 if(bath?.complete&&bath.naturalWidth){ctx.save();ctx.translate(984,739);
  ctx.rotate(-.55*ease(bathDoorMotion));ctx.drawImage(bath,978-984,733-739);ctx.restore();}
 // Bedroom doorway has no original leaf to duplicate; introduce a single oak door in its frame.
 if(bedroomDoorAngle>.10){const hingeX=914,hingeY=517;
  ctx.save();ctx.globalAlpha=Math.min(1,bedroomDoorAngle*2.4);
  ctx.translate(hingeX,hingeY);ctx.rotate(-bedroomDoorAngle*1.33);
  ctx.fillStyle='#3b2b27';ctx.fillRect(-5,0,10,82);
  ctx.fillStyle='#866047';ctx.fillRect(-2,2,7,78);
  ctx.fillStyle='#b98b63';ctx.fillRect(1,3,2,73);
  ctx.fillStyle='#e8c889';ctx.fillRect(1,56,3,5);
  ctx.restore();}
}
function updateDoors(dt){
 const bedroomNear=Math.hypot(player.x-922,player.y-554)<115;
 const frontNear=Math.hypot(player.x-755,player.y-884)<126;
 const bathNear=Math.hypot(player.x-994,player.y-790)<104;
 frontDoorMotion+=(Number(frontNear)-frontDoorMotion)*Math.min(1,dt*3.3);
 bathDoorMotion+=(Number(bathNear)-bathDoorMotion)*Math.min(1,dt*3.3);
 bedroomDoorAngle+=(Number(bedroomNear)-bedroomDoorAngle)*Math.min(1,dt*4.5);
 const near=Math.abs(player.x-614)<115&&Math.abs(player.y-206)<112;
 const target=near?1:0;
 balconyOpening+=(target-balconyOpening)*Math.min(1,dt*5.5);
}
// Stable deterministic particle seeds: arrays are tiny and reuse the same objects.
const rng=(n)=>{let v=Math.sin(n*111.371+23.77)*43758.5453;return v-Math.floor(v)};
const particles=Array.from({length:135},(_,i)=>({x:rng(i*6+1),y:rng(i*6+2),speed:.5+rng(i*6+3)*1.35,size:.9+rng(i*6+4)*1.6,seed:rng(i*6+5)*9}));
const dust=Array.from({length:20},(_,i)=>({x:340+rng(i+1)*455,y:260+rng(i+31)*375,phase:rng(i+92)*6.28}));
// Audio policy: no active WebAudio context in the background, even on Android WebView.
let ambientOn=false,audioContext=null,audioNode=null,audioFilter=null;
const soundButton=$('#sound');
function syncSoundUI(){soundButton.textContent=ambientOn?'Sound ON':'Sound OFF';soundButton.setAttribute('aria-pressed',String(ambientOn));}
function isForeground(){return !gamePaused&&!document.hidden&&document.visibilityState!=='hidden';}
function audioSuspend(){if(audioNode&&audioContext)audioNode.gain.setTargetAtTime(0,audioContext.currentTime,.05);if(audioContext&&audioContext.state==='running')audioContext.suspend().catch(()=>{});}
function audioResume(){if(audioContext&&ambientOn&&isForeground()&&audioContext.state!=='running')audioContext.resume().catch(()=>{});}
function toggleSound(){ambientOn=!ambientOn;try{localStorage.setItem('thepianist.sound.v1',ambientOn?'1':'0')}catch(_){}
 syncSoundUI();if(!ambientOn){audioSuspend();return}
 try{if(!audioContext){audioContext=new (window.AudioContext||window.webkitAudioContext)();
   const count=audioContext.sampleRate*3,buf=audioContext.createBuffer(1,count,audioContext.sampleRate),a=buf.getChannelData(0);
   let prev=0;for(let i=0;i<count;i++){const n=(Math.random()*2-1);prev=.972*prev+.028*n;a[i]=prev*2.4}
   const src=audioContext.createBufferSource();src.buffer=buf;src.loop=true;
   audioFilter=audioContext.createBiquadFilter();audioFilter.type='lowpass';audioFilter.frequency.value=670;
   audioNode=audioContext.createGain();audioNode.gain.value=0;
   src.connect(audioFilter).connect(audioNode).connect(audioContext.destination);src.start()}
 audioResume();}catch(e){ambientOn=false;syncSoundUI();notice('Audio unavailable')}
}
soundButton.addEventListener('click',toggleSound);
function updateAmbient(){if(!audioNode||!audioContext)return;
 if(!ambientOn||!isForeground()){if(audioContext.state==='running')audioNode.gain.setTargetAtTime(0,audioContext.currentTime,.08);return;}
 if(audioFilter)audioFilter.frequency.setTargetAtTime(weather==='storm'?1100:weather==='rainy'?800:weather==='windy'?340:450,audioContext.currentTime,.2);
 const gain=weather==='rainy'?.105:weather==='storm'?.135:weather==='windy'?.055:0;
 if(audioContext.state==='running')audioNode.gain.setTargetAtTime(gain,audioContext.currentTime,.25);
}
function enterBackground(){gamePaused=true;resetJoystick();keyState.clear();audioSuspend();}
function enterForeground(){gamePaused=false;last=performance.now();audioResume();}
window.__pianistPause=enterBackground;window.__pianistResume=enterForeground;
document.addEventListener('visibilitychange',()=>document.hidden?enterBackground():enterForeground());
window.addEventListener('pagehide',enterBackground);window.addEventListener('pageshow',enterForeground);
try{const savedAudio=localStorage.getItem('thepianist.sound.v1');ambientOn=savedAudio===null?true:savedAudio==='1'}catch(_){ambientOn=true}
// Resume a saved ON preference at the first game gesture (browser autoplay policy).
window.addEventListener('pointerdown',e=>{
 if(ambientOn&&!audioContext&&!e.target.closest('#sound')){
  ambientOn=false;toggleSound();
 }
},{capture:true});
syncSoundUI();
// All drawing happens in WORLD coordinates, translated by the vertical look-up camera.
function drawWorldImage(img,opacity=1){if(!img.complete||!img.naturalWidth)return;ctx.save();ctx.globalAlpha=opacity;ctx.drawImage(img,0,0,W,H);ctx.restore()}
function drawCourtyard(){
 const a=files['world_'+lastLight],b=files['world_'+lightMode];
 if(lightAmount<1&&lastLight!==lightMode){
  if(a?.complete&&a.naturalWidth)ctx.drawImage(a,0,-380,W,1404);
  if(b?.complete&&b.naturalWidth){ctx.save();ctx.globalAlpha=ease(lightAmount);ctx.drawImage(b,0,-380,W,1404);ctx.restore()}
 }else if(b?.complete&&b.naturalWidth)ctx.drawImage(b,0,-380,W,1404);
 drawAnimatedTrees();
}
function drawAnimatedTrees(){
 // Each crown is a separate transparent drawing with its own gentle wind offset.
 const img=files['trees_'+lightMode];if(!img?.complete||!img.naturalWidth)return;
 const strength=weather==='windy'?1.65:weather==='storm'?2.2:weather==='rainy'?.35:.14;
 const tr=[[352,270,42],[583,243,46],[776,271,32],[972,243,47],[1154,290,40]];
 ctx.save();ctx.imageSmoothingEnabled=true;
 for(let i=0;i<tr.length;i++){
  const [x,y,r]=tr[i],sx=x-r-22,sy=y-r-20,sz=r*2+44;
  const sw=Math.sin(time*(weather==='storm'?3.7:2.0)+i*.88)*strength*4;
  const ww=Math.cos(time*(weather==='storm'?3.1:1.4)+i*1.73)*strength*2;
  ctx.drawImage(img,sx-302,sy-205,sz,sz,sx+sw,sy-380+ww,sz,sz);
 }
 ctx.restore();
}
function drawBedroomWindow(){
 // Physically embedded in the upper wall, not a pasted-on landscape billboard.
 const x=978,y=128,w=348,h=43;
 const world=files['world_'+lightMode];
 ctx.save();
 // Recessed reveal, sill, mullion, subtle glazing. The SAME continuous courtyard.
 ctx.fillStyle='#26292c';ctx.fillRect(x-5,y-5,w+10,h+11);
 ctx.fillStyle='#d5c7ad';ctx.fillRect(x-5,y-6,w+10,4);
 ctx.beginPath();ctx.rect(x+5,y+2,w-10,h-6);ctx.clip();
 if(world?.complete&&world.naturalWidth){ctx.drawImage(world,x+10,217,w-20,80,x+2,y+2,w-4,h-5)}
 ctx.restore();ctx.save();
 ctx.strokeStyle='#c5bbaa';ctx.lineWidth=4;ctx.strokeRect(x+1,y+1,w-2,h-2);
 ctx.fillStyle='#b9b3a3';ctx.fillRect(x+w*.5-3,y+2,6,h-3);
 ctx.fillStyle='rgba(217,239,239,.10)';ctx.fillRect(x+5,y+4,w-10,h-9);
 ctx.fillStyle='#7f7d72';ctx.fillRect(x-6,y+h-1,w+12,7);
 ctx.restore();
}
function drawBase(){
 const a=files['light_'+lastLight],b=files['light_'+lightMode];
 ctx.save();
 // This clip removes only the EXTERIOR background from the source image: every
 // original wall, floor, bed, piano and furnishing stays within the same coordinates.
 ctx.beginPath();
 ctx.moveTo(197,16);ctx.lineTo(860,16);ctx.lineTo(860,123);
 ctx.lineTo(1401,123);ctx.lineTo(1401,967);ctx.lineTo(853,967);
 ctx.lineTo(853,1023);ctx.lineTo(708,1023);ctx.lineTo(708,967);
 ctx.lineTo(111,967);ctx.lineTo(111,149);ctx.lineTo(197,149);
 ctx.closePath();ctx.clip();
 if(lightAmount<1&&lastLight!==lightMode){drawWorldImage(a);drawWorldImage(b,ease(lightAmount))}
 else drawWorldImage(b);
 ctx.restore();
}
// Time-dependent indoor illumination. Day plates have unlit sources;
// night plate retains lamps; localized glows are additive with nearby furniture.
function glow(x,y,r,alpha,color='255,195,114'){
 const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${color},${alpha})`);g.addColorStop(.3,`rgba(${color},${alpha*.42})`);g.addColorStop(1,`rgba(${color},0)`);ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)
}
function timeLight(){
 // No full-screen colour filter. The five separately painted base scenes already
 // determine wall, flooring and furniture colours. Only physical lamp glows vary.
 const night=lightMode==='night'?ease(lightAmount):lastLight==='night'?1-ease(lightAmount):0;
 if(night<=0)return;
 ctx.save();ctx.globalCompositeOperation='screen';
 glow(307,277,150,.21*night);glow(850,353,110,.16*night);glow(1247,254,118,.19*night);
 for(const [x,y] of [[332,66],[407,51],[480,78],[555,70],[611,95],[670,81],[786,62]])
   glow(x,y,19,(.17+.045*Math.sin(time*1.25+x))*night);
 ctx.restore();
}
function outdoorTint(){
 const cloud=weather==='cloudy'?.08:weather==='foggy'?.13:weather==='rainy'?.10:weather==='storm'?.19:weather==='snowy'?.05:0;
 if(!cloud)return;
 ctx.fillStyle=`rgba(39,64,78,${cloud})`;
 ctx.fillRect(0,-380,W,380);
}
function drawWeather(){
 const rain=weather==='rainy'||weather==='storm',snow=weather==='snowy',wind=weather==='windy'||weather==='storm';
 if(weather==='foggy'){
  // Exterior air only; fog does not tint the apartment furnishings.
  ctx.save();ctx.fillStyle='rgba(201,216,213,.11)';ctx.fillRect(0,-380,W,385);ctx.restore();
 }
 if(!rain&&!snow&&!wind)return;
 ctx.save();
 // Two connected outdoor regions: the wide courtyard and the open balcony deck.
 ctx.beginPath();ctx.rect(0,-380,W,390);ctx.rect(237,35,588,143);ctx.clip();
 const count=snow?156:rain?215:50;
 for(let i=0;i<count;i++){
  const pt=particles[i%particles.length],phase=Math.floor(i/particles.length)*.57;
  const fall=snow?(35+pt.speed*19):rain?(235+pt.speed*104):(92+pt.speed*30);
  const yy=((pt.y*567+phase*129+time*fall)%575)-380;
  const xx=((pt.x*1501+i*37+time*(wind?65:rain?-32:29))%1510+1510)%1510+13;
  if(snow){
   ctx.fillStyle=`rgba(249,251,255,${.45+.32*rng(i+6)})`;
   ctx.beginPath();ctx.arc(xx+Math.sin(time*1.9+i)*3,yy,pt.size*(i%3===0?1.5:1),0,Math.PI*2);ctx.fill();
  }else if(rain){
   ctx.strokeStyle=weather==='storm'?'rgba(183,220,241,.79)':'rgba(167,206,232,.77)';
   ctx.lineWidth=i%3===0?1.9:1.25;ctx.beginPath();ctx.moveTo(xx,yy);ctx.lineTo(xx-(weather==='storm'?10:4),yy+(weather==='storm'?19:13));ctx.stroke();
  }else{ctx.fillStyle='rgba(177,194,175,.36)';ctx.fillRect(xx,yy,8,1.5)}
 }
 ctx.restore();
 if(rain){
  // Deck becomes wet only in rain, plus tiny splashes and warm fairy-light reflections.
  ctx.save();ctx.fillStyle='rgba(45,73,87,.17)';ctx.fillRect(240,99,581,74);
  for(let i=0;i<40;i++){
   const xx=246+rng(i*7+20)*566,yy=107+rng(i*5+8)*63;
   const life=(time*3+rng(i+32))%1;
   ctx.strokeStyle=`rgba(181,213,226,${.28*(1-life)})`;
   ctx.lineWidth=1.4;ctx.beginPath();ctx.ellipse(xx,yy,2+life*6,.7+life*2,0,0,Math.PI*2);ctx.stroke();
  }
  ctx.restore();
  // Glass traces visibly communicate rain even when camera is centred on the living room.
  ctx.save();ctx.beginPath();ctx.rect(239,177,590,47);ctx.rect(1019,136,246,31);ctx.clip();
  for(let i=0;i<26;i++){
    const px=(i<18?242+rng(i*19+6)*581:1020+rng(i*11+2)*243);
    const py=(i<18?179:137)+((time*(18+rng(i*7)*23)+i*13)%(i<18?45:32));
    ctx.strokeStyle='rgba(208,229,238,.43)';ctx.lineWidth=1.2;
    ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px-1,py+5);ctx.stroke();
  }ctx.restore();
 }
 if(snow){ctx.save();ctx.strokeStyle='rgba(234,240,244,.78)';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(239,177);ctx.lineTo(827,177);ctx.stroke();ctx.restore()}
}
function animatedPlants(){const windy=weather==='windy'||weather==='storm'?1:weather==='rainy'?.35:.11;
 ctx.save();for(const [x,y,len] of [[268,112,21],[217,260,15],[831,265,11],[1347,570,14]]){
   const sway=Math.sin(time*(windy?2.4:1.1)+x)*windy*3;ctx.strokeStyle='rgba(72,113,64,.8)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y+len);ctx.quadraticCurveTo(x+sway-5,y+3,x+sway,y);ctx.stroke();ctx.fillStyle='#698250';ctx.beginPath();ctx.ellipse(x+sway,y-1,7,3,sway*.02,0,6.28);ctx.fill()
 }ctx.restore();}
function ambientDust(){if(lightMode==='night'||weather==='storm'||weather==='rainy')return;ctx.save();for(const d of dust){const drift=Math.sin(time*.42+d.phase)*14;ctx.globalAlpha=.17+.12*Math.sin(time*.7+d.phase);ctx.fillStyle='#fff7d0';ctx.fillRect(d.x+drift,d.y+Math.cos(time*.37+d.phase)*5,2,2)}ctx.restore()}
// Diagonal atlas is separately prepared from the approved original sprite design.
const spriteRow={down:0,left:1,right:2,up:3,'down-left':4,'down-right':5,'up-left':6,'up-right':7};
function drawWalking(x,y,dir,moving,phase,opacity=1,scale=1){
 const diagonal=dir.includes('-');
 const img=moving?(diagonal?files.diagonal_indoor:files.walk_indoor):files.idle_indoor;
 if(!img?.complete||!img.naturalWidth)return;
 ctx.save();ctx.globalAlpha=opacity;ctx.imageSmoothingEnabled=false;ctx.filter=actorFilter(x,y);
 const fw=101*scale,fh=143*scale;
 if(moving){
  const row=diagonal?({'down-left':0,'down-right':1,'up-left':2,'up-right':3}[dir]??0):(spriteRow[dir]??0);
  const frame=Math.floor(phase*8)%4;
  ctx.drawImage(img,frame*80,row*112,80,112,x-fw/2,y-fh,fw,fh);
 }else{
  const neutral=dir==='up'||dir==='up-left'||dir==='up-right'?3:
   dir==='left'||dir==='down-left'?1:dir==='right'||dir==='down-right'?2:0;
  ctx.drawImage(img,neutral*80,0,80,112,x-fw/2,y-fh,fw,fh);
 }
 ctx.restore();ctx.imageSmoothingEnabled=true;
}
function drawSitting(x,y,face,phase,opacity=1,scale=.85,beanbag=false){
 // Individually approved seated artwork contains the human ONLY, never a chair.
 const img=beanbag?files.beanbag_indoor:files.sitting_indoor;
 if(!img?.complete||!img.naturalWidth)return;
 const index=face==='right'?1:face==='left'?2:face==='up'?3:0;
 ctx.save();ctx.globalAlpha=opacity;ctx.imageSmoothingEnabled=false;ctx.filter=actorFilter(x,y);
 const w=113*scale,h=148*scale;
 const bob=Math.sin(time*.75)*.24;
 ctx.drawImage(img,index*128,0,128,170,x-w/2,y-h+bob,w,h);
 ctx.restore();ctx.imageSmoothingEnabled=true;
}
function drawReclining(p){
 if(p.id==='bed'){
  const img=files.walk_indoor;
  if(img?.complete&&img.naturalWidth){ctx.save();ctx.filter=actorFilter(p.x,p.y);
   ctx.imageSmoothingEnabled=false;ctx.drawImage(img,3,4,74,64,p.x-50,p.y-70,100,84);ctx.restore();}
  return;
 }
 // Approved anatomically proportionate reclining sprite, shoes removed for indoor use.
 const img=files.sofa_recline_approved;
 if(img?.complete&&img.naturalWidth){ctx.save();ctx.filter=actorFilter(p.x,p.y);
  ctx.imageSmoothingEnabled=false;ctx.drawImage(img,p.x-117,p.y-60,234,104);ctx.restore();}
}
function renderRest(p){
 if(p.type==='sit')drawSitting(p.x,p.y+(p.id==='sofa'?18:0),p.face,0,1,p.id==='beanbag'?.80:p.id==='balchair'?.72:p.id==='sofa'?.83:p.id==='bed'?.84:.85,p.id==='beanbag');
 else drawReclining(p);
 if(p.id==='bed'){
  if(p.type==='lie'){
   const img=files.duvet_foreground;
   if(img.complete&&img.naturalWidth){ctx.save();ctx.drawImage(img,994,338,222,130);ctx.restore();}
  } else{
   const img=files['light_'+lightMode];
   if(img.complete&&img.naturalWidth)ctx.drawImage(img,1002,514,209,30,1002,514,209,30);
  }
 }
 if(p.id==='sofa'&&p.type==='sit'){
  // Refined front edge shading, only around cushion lip and legs, no character-obscuring stripe.
  const img=files['light_'+lightMode];
  if(img.complete&&img.naturalWidth){ctx.save();ctx.globalAlpha=.7;
   ctx.drawImage(img,302,338,275,5,302,338,275,5);ctx.restore()}
 }
 if(p.id==='beanbag'){
  const im=files['light_'+lightMode];if(im?.complete&&im.naturalWidth){
   // Original beanbag cushion foreground, no invented dark shape pasted over the chair.
   ctx.save();ctx.drawImage(im,722,151,82,19,722,151,82,19);ctx.restore();
  }
 }
}
function drawShoesAtEntrance(){
 // Character removes shoes at entrance. Existing interior sprites have charcoal socks.
 const img=files.walk_indoor;if(!img?.complete||!img.naturalWidth)return;
 ctx.save();ctx.fillStyle='rgba(22,24,28,.23)';ctx.beginPath();ctx.ellipse(830,854,23,7,0,0,Math.PI*2);ctx.fill();
 // Two understated shoes beside the mat, not blocking movement.
 ctx.fillStyle='#29262a';ctx.strokeStyle='#1b1b20';ctx.lineWidth=2;
 for(const x of [818,833]){ctx.beginPath();ctx.roundRect(x,846,11,19,4);ctx.fill();ctx.stroke();
  ctx.fillStyle='#49474b';ctx.fillRect(x+3,850,5,2);ctx.fillStyle='#29262a';}
 ctx.restore();
}
function drawPlayer(){const t=player.transition;
 if(t){const f=ease(clamp(t.t/0.7,0,1));const x=t.fromX+(t.toX-t.fromX)*f,y=t.fromY+(t.toY-t.fromY)*f;
   if(t.kind==='enter'){
      if(f<.44){drawShadow(x,y);drawWalking(x,y,t.face,f<.31,0)}
      else if(f<.70){
        // A single crouching figure bends into the seat; never a translucent duplicate.
        const squash=1-.23*ease((f-.44)/.26);
        ctx.save();ctx.translate(0,y);ctx.scale(1,squash);ctx.translate(0,-y);
        drawWalking(x,y,t.face,false,0);ctx.restore();
      }else {renderRest({id:t.id,type:t.type,x:t.toX,y:t.toY,face:t.face})}
   }else{
      if(f<.28){renderRest({id:t.id,type:t.type,x:t.fromX,y:t.fromY,face:t.face})}
      else if(f<.55){const squash=.77+.23*ease((f-.28)/.27);
        ctx.save();ctx.translate(0,y);ctx.scale(1,squash);ctx.translate(0,-y);
        drawWalking(x,y,t.face,false,0);ctx.restore();
      }else {drawShadow(x,y);drawWalking(x,y,t.face,false,0)}
   }return;
 }
 if(player.pose){renderRest(player.pose);return}
 drawShadow(player.x,player.y);drawWalking(player.x,player.y,player.dir,player.moving,player.phase);
}
function actorFilter(x,y){
 // Region-aware illumination: sunlight entering from the balcony, shadow beside furniture,
 // cool night ambient and warm nearby lamps. Respect approved skin/hair palette.
 let bright=lightMode==='night'?.70:lightMode==='sunrise'?.92:lightMode==='sunset'?.93:lightMode==='morning'?.99:1.02;
 if(weather==='cloudy'||weather==='foggy'||weather==='rainy')bright*=.94;
 if(weather==='storm')bright*=.88;
 const underSofa=(x<590&&y>242&&y<365);
 if(underSofa)bright*=.91;
 const sunPatch=(x>575&&x<950&&y>214&&y<570)&&lightMode!=='night';
 if(sunPatch)bright+=lightMode==='sunset'?.16:lightMode==='sunrise'?.11:.07;
 if(lightMode==='night'){
  for(const [lx,ly,r] of [[305,258,210],[845,318,130],[1250,250,170]]){
   bright+=.23*clamp(1-Math.hypot(x-lx,y-ly)/r,0,1);
  }
 }
 const sat=lightMode==='night'?.81:lightMode==='sunset'?1.16:1.02;
 const warmth=lightMode==='sunset'?'sepia(.19)':lightMode==='sunrise'?'sepia(.08)':lightMode==='night'?'sepia(.03)':'sepia(0)';
 return `brightness(${clamp(bright,.54,1.2).toFixed(3)}) saturate(${sat}) ${warmth}`;
}
function drawShadow(x,y){ctx.save();ctx.fillStyle='rgba(19,24,28,.22)';ctx.beginPath();ctx.ellipse(x,y-3,19,6,0,0,Math.PI*2);ctx.fill();ctx.restore()}
function lightingOnSprite(){if(lightMode==='night'){
  const dx=player.x-307,dy=player.y-270,near=clamp(1-Math.hypot(dx,dy)/240,0,1);
  const dx2=player.x-1248,dy2=player.y-249,near2=clamp(1-Math.hypot(dx2,dy2)/170,0,1);
  const bright=Math.max(near,near2);if(bright>.01)glow(player.x,player.y-55,40,.075*bright);
 }}
function draw(){if(!ready){ctx.fillStyle='#111720';ctx.fillRect(0,0,W,H);return;}ctx.fillStyle='#111720';ctx.fillRect(0,0,W,H);ctx.save();ctx.translate(0,cameraY);
 // Outdoors lives BEHIND the original approved apartment at world y < 0.
 drawCourtyard();outdoorTint();
 // See the courtyard only where original image had empty sky margin at its top;
 // the user-approved furniture and walls remain pixel-for-pixel untouched.
 drawBase();drawBedroomWindow();drawBalconyDoor();drawPhysicalDoors();
 // Balcony reveal comes from gentle camera look-up; never paste a band over the flat.
 ambientDust();drawWeather();updateAmbient();
 timeLight();
 // No duplicate door leaf over the original artwork.
 drawShoesAtEntrance();drawPlayer();lightingOnSprite();
 // The railing belongs IN FRONT of anyone leaning near it (occlusion, not walk-through).
 if(player.y<205&&!player.pose){const front=files['light_'+lightMode];
  if(front?.complete&&front.naturalWidth){ctx.save();ctx.drawImage(front,234,44,598,82,234,44,598,82);ctx.restore();}}

 if(stormFlash>0){ctx.fillStyle=`rgba(211,224,255,${stormFlash*.43})`;ctx.fillRect(230,-350,1130,1330)}
 ctx.restore();}
function tick(ts){const dt=gamePaused?0:clamp((ts-last)/1000||0,0,.041);last=ts;time+=dt;
 lightAmount=clamp(lightAmount+dt/2.3,0,1);
 if(lightAmount===1&&lastLight!==lightMode){discardMode(lastLight);lastLight=lightMode;}weatherBlend=clamp(weatherBlend+dt/1.4,0,1);
 stormFlash=Math.max(0,stormFlash-dt*3.0);if(weather==='storm'&&time>stormNext){stormFlash=1;stormNext=time+6+rng(Math.floor(time))*12}
 let vx=joy.x,vy=joy.y;
 if(keyState.has('ArrowLeft')||keyState.has('a'))vx--;
 if(keyState.has('ArrowRight')||keyState.has('d'))vx++;
 if(keyState.has('ArrowUp')||keyState.has('w'))vy--;
 if(keyState.has('ArrowDown')||keyState.has('s'))vy++;
 if(!dialogue.hidden||!$('#modal').hidden||!$('#controlsPanel').hidden||gamePaused||player.transition){vx=0;vy=0}
 const mag=Math.hypot(vx,vy);if(player.pose&&mag>.18){stand();vx=vy=0}
 if(player.transition){const t=player.transition;t.t+=dt;player.x=t.fromX+(t.toX-t.fromX)*ease(clamp(t.t/.7,0,1));player.y=t.fromY+(t.toY-t.fromY)*ease(clamp(t.t/.7,0,1));
   if(t.t>=.7){if(t.kind==='enter'){player.pose={id:t.id,type:t.type,x:t.toX,y:t.toY,exit:t.exit,face:t.face};player.x=t.toX;player.y=t.toY}
      else{player.x=t.toX;player.y=t.toY;player.dir=t.face}player.transition=null}}
 else if(!player.pose&&mag>.13){const analog=keyState.size>0?1:clamp((mag-.13)/.87,0,1);vx/=mag;vy/=mag;player.moving=true;
   const ax=Math.abs(vx),ay=Math.abs(vy);player.dir=(ax>.33&&ay>.33&&Math.min(ax,ay)/Math.max(ax,ay)>.42)?(vy<0?'up-':'down-')+(vx<0?'left':'right'):(ax>ay?(vx<0?'left':'right'):(vy<0?'up':'down'));
   const speed=18+175*Math.pow(analog,1.32);player.speed=speed;const n=Math.max(1,Math.ceil(speed*dt/3));for(let i=0;i<n;i++){const x=player.x+vx*speed*dt/n,y=player.y+vy*speed*dt/n;
     if(passable(x,player.y))player.x=x;if(passable(player.x,y))player.y=y}
   player.phase+=dt*(.20+1.55*analog);
 }else{player.moving=false;player.phase=0;player.speed=0}
 updateDoors(dt);
 // When near balcony, gently lift camera; leave flat at full original scale.
 const target=player.y<255?clamp((255-player.y)/150,0,1)*184:0;
 cameraY+=(target-cameraY)*Math.min(1,dt*3.2);
 if(!dialogue.hidden){const chars=clamp(Math.floor((ts-dialogueStart)/23),0,dialogueFull.length);if(dlgText.textContent.length<chars)dlgText.textContent=dialogueFull.slice(0,chars)}
 try{draw()}catch(error){console.error('Rendering frame failed',error);
  const el=document.querySelector('#loadStatus');if(el){el.hidden=false;el.textContent='Rendering error. Restart the game.';}}
 requestAnimationFrame(tick)}requestAnimationFrame(tick);
const pad=$('#joystick'),stick=$('#stick'),actionButton=$('#action');
function movePad(e){if(layoutEdit)return;const r=pad.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,limit=r.width*.43;let x=e.clientX-cx,y=e.clientY-cy,m=Math.hypot(x,y);if(m>limit){x*=limit/m;y*=limit/m}joy={x:x/limit,y:y/limit};stick.style.left=(50+x/r.width*100)+'%';stick.style.top=(50+y/r.height*100)+'%'}
function resetJoystick(){joy={x:0,y:0};stick.style.left=stick.style.top='50%'}
pad.addEventListener('pointerdown',e=>{if(layoutEdit)return;e.preventDefault();pad.setPointerCapture(e.pointerId);movePad(e)});
pad.addEventListener('pointermove',e=>{if(pad.hasPointerCapture(e.pointerId))movePad(e)});
pad.addEventListener('pointerup',resetJoystick);pad.addEventListener('pointercancel',resetJoystick);
actionButton.addEventListener('pointerdown',e=>{if(layoutEdit)return;e.preventDefault();interact()});
// User-adjustable touch controls. Coordinates are normalized to the stage size, not APK version.
const controlsPanel=$('#controlsPanel'),controlEditButton=$('#controlEdit');
const layoutKey='thepianist.controls.v1';
const defaults={pad:{x:.079,y:.884,size:118},action:{x:.927,y:.84,size:114},opacity:.68};
let layout=JSON.parse(JSON.stringify(defaults)),layoutEdit=false,dragging=null;
try{const stored=JSON.parse(localStorage.getItem(layoutKey)||'null');if(stored&&stored.pad&&stored.action){
 for(const key of ['pad','action']){
  layout[key].x=clamp(Number(stored[key].x)||defaults[key].x,.06,.94);
  layout[key].y=clamp(Number(stored[key].y)||defaults[key].y,.10,.94);
  layout[key].size=clamp(Number(stored[key].size)||defaults[key].size,65,210);
 }
 layout.opacity=clamp(Number(stored.opacity)||.68,.2,1);
}}catch(_){}
function saveLayout(){try{localStorage.setItem(layoutKey,JSON.stringify(layout))}catch(_){notice('Control settings could not be saved')}}
function placeControls(){const r=$('#stage').getBoundingClientRect();
 for(const [name,el] of [['pad',pad],['action',actionButton]]){
  const setting=layout[name],size=Math.min(setting.size,r.height*.37,r.width*.25);
  const cx=clamp(setting.x*r.width,size/2+6,r.width-size/2-6),cy=clamp(setting.y*r.height,size/2+6,r.height-size/2-6);
  el.style.left=(cx-size/2)+'px';el.style.top=(cy-size/2)+'px';el.style.right='auto';el.style.bottom='auto';
  el.style.width=size+'px';el.style.height=size+'px';el.style.opacity=String(layout.opacity);
 }
}
function setControlEdit(active){layoutEdit=active;document.body.classList.toggle('editing-controls',active);resetJoystick();
 $('#controlInstructions').textContent=active?'Drag joystick / Interact to move them. Tap Done when satisfied.':'Sizes and positions save automatically across app updates.';
 $('#editControls').textContent=active?'Done positioning':'Move controls';
}
function updateSliders(){ $('#padSize').value=String(layout.pad.size);$('#padSizeValue').textContent=layout.pad.size+'px';
 $('#actionSize').value=String(layout.action.size);$('#actionSizeValue').textContent=layout.action.size+'px';
 $('#controlsOpacity').value=String(Math.round(layout.opacity*100));$('#controlsOpacityValue').textContent=Math.round(layout.opacity*100)+'%';}
function openControls(){controlsPanel.hidden=false;$('#modal').hidden=true;lightMenu.hidden=true;weatherMenu.hidden=true;updateSliders();placeControls();resetJoystick()}
function closeControls(){setControlEdit(false);controlsPanel.hidden=true;saveLayout()}
controlEditButton.addEventListener('click',openControls);
$('#editControls').addEventListener('click',()=>setControlEdit(!layoutEdit));
$('#closeControls').addEventListener('click',closeControls);
$('#resetControls').addEventListener('click',()=>{layout=JSON.parse(JSON.stringify(defaults));updateSliders();placeControls();saveLayout()});
for(const [id,field,name,unit] of [['padSize','pad','size','px'],['actionSize','action','size','px'],['controlsOpacity',null,'opacity','%']]){
 $('#'+id).addEventListener('input',e=>{const v=Number(e.target.value);if(field)layout[field][name]=v;else layout[name]=v/100;
  $('#'+id+'Value').textContent=v+unit;placeControls();saveLayout()});
}
function dragControl(el,which){el.addEventListener('pointerdown',e=>{if(!layoutEdit)return;e.stopImmediatePropagation();e.preventDefault();
 dragging={id:e.pointerId,which};el.setPointerCapture(e.pointerId);
 });
 el.addEventListener('pointermove',e=>{if(!layoutEdit||!dragging||dragging.id!==e.pointerId||dragging.which!==which)return;
  const r=$('#stage').getBoundingClientRect();layout[which].x=clamp((e.clientX-r.left)/r.width,.01,.99);
  layout[which].y=clamp((e.clientY-r.top)/r.height,.01,.99);placeControls();});
 el.addEventListener('pointerup',e=>{if(dragging?.id===e.pointerId){dragging=null;saveLayout()}});
 el.addEventListener('pointercancel',()=>{dragging=null;saveLayout()});
}
dragControl(pad,'pad');dragControl(actionButton,'action');
window.addEventListener('resize',placeControls);placeControls();
window.addEventListener('keydown',e=>{const k=e.key.length===1?e.key.toLowerCase():e.key;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(k))e.preventDefault();keyState.add(k);if((k==='e'||k===' ')&&!e.repeat)interact()});
window.addEventListener('keyup',e=>keyState.delete(e.key.length===1?e.key.toLowerCase():e.key));
window.addEventListener('blur',()=>{keyState.clear();resetJoystick();audioSuspend()});
window.addEventListener('focus',()=>{if(!gamePaused)audioResume()});
$('#help').onclick=()=>{$('#modal').hidden=false;resetJoystick()};$('#close').onclick=()=>$('#modal').hidden=true;
// Debug-only hooks for screenshot/geometry tests, inert during normal play.
window.__pianistTest={getState:()=>({x:player.x,y:player.y,dir:player.dir,pose:player.pose,lightMode,weather,cameraY,balconyOpening,layout,gamePaused,ambientOn,speed:player.speed,bedroomDoorAngle,frontDoorMotion,bathDoorMotion}),setPlayer:(x,y,dir)=>{player.x=x;player.y=y;player.dir=dir||player.dir;player.pose=null;player.transition=null},setLighting,setWeather,passable,interact,actorFilter,enterBackground,enterForeground,placeControls,isReady:()=>ready,loadedImages:()=>Object.keys(files).filter(n=>files[n]?.naturalWidth)};
})();
