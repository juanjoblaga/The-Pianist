# The Pianist v0.3.9 — lean scene loader & character refinement

Android Gradle source project for building through GitHub Actions. Java 17, Gradle 8.9, Android Gradle Plugin as in original project.

- Preserves Android package `com.thepianist.game`, signing keystore and WebView `file:///android_asset/` storage origin.
- v0.3.9 / versionCode 12. Install on top of existing version; never uninstall or clear app data.
- Loads *only one* set of five scene images at startup (world, apartment, tree crown, entrance & bathroom door), loads a second only for time-of-day transition, and releases the previous set.
- Crops transparent tree animation layers to actual art pixels rather than 1536×1404 full canvases.
- Integrates approved diagonal walking, chair-free sitting, relaxed beanbag pose and proportionate sofa reclining artwork. The sofa recline is still a single side-facing illustrated pose, not a fully animated supine pose. Do not describe it as completed animation.
- Persistent touch controls and dialogue UI unchanged; bedroom rear wall and balcony railing collision tightened; socks indoor and decorative shoes at entry.
- Android WebView renderer failure shows a recovery screen instead of silently terminating the Activity, and writes startup/JS diagnostics to `ThePianist` log tag.
- **No Android APK was compiled or device-installed in the authoring environment.** Test on the device and get logcat if startup still fails.
- `game/` holds readable gameplay source. `app/src/main/assets/` contains the matching runtime files. Source PNG and JPEG illustrations retain the same full art resolution.

Build: `gradle --no-daemon assembleDebug` in this directory, from the supplied GitHub Actions workflow.
