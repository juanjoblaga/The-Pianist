# The Pianist v0.3.2 — character restoration

Uses the previously approved character artwork from v0.2 (preserving transparent background and opaque skin/clothing), with walking frames and feet anchored to the floor. Preserves the v0.3.1 apartment, entrance, interactions, launcher icon and permanent prototype signing keystore.

**Important:** This is a targeted sprite update, not a complete remake of the room or a new narrative. The walk cycle is an initial simple four-frame animation; side and back frames still need dedicated hand-drawn artwork for final quality.

Upload the ZIP as-is to your private GitHub repository and run the existing Build The Pianist APK workflow. The workflow must select this v0.3.2 ZIP, not an older one. Package com.thepianist.game, versionCode 5, versionName 0.3.2. The bundled keystore is unchanged from v0.3.1. Keep it private and backed up. APK build has not been tested on GitHub Actions.
