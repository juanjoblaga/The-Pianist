THE PIANIST — Android prototype 0.3.0

This is a landscape, offline WebView game. It retains the approved apartment illustration, with a relocated console/intercom, bedroom threshold and a bathroom door. Includes opaque animated four-direction character, collision zones, and proximity + facing-based interaction labels. No narrative content.

BUILD: Upload this ZIP unextracted at the root of your The-Pianist GitHub repository, then run the existing Build The Pianist APK GitHub Actions workflow. The ZIP contains settings.gradle and is compatible with the workflow that searches for either settings.gradle or settings.gradle.kts.

VERSION: applicationId com.thepianist.game, versionCode 3, versionName 0.3.0. The current workflow uses ephemeral debug signing, so Android may refuse installation over v0.2.0 because of a signing mismatch. Back up anything you need before uninstalling. A persistent signing key in GitHub Secrets and a signing-aware workflow are recommended for future in-place upgrades. Do not put a private release signing key inside a public source ZIP.

KNOWN LIMITATION: The approved apartment artwork is a single flattened image, not a true layered tileset. Doors and moved furniture are reconstructed in the artwork. Depth-sorting/occlusion remains limited.
