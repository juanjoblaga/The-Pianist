package com.thepianist.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView gameView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        gameView = new WebView(this);
        gameView.setBackgroundColor(0xff10131c);
        gameView.setWebViewClient(new WebViewClient());
        WebSettings settings = gameView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        setContentView(gameView);
        gameView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onPause() { if(gameView!=null){gameView.evaluateJavascript("window.__pianistPause && window.__pianistPause();", null);gameView.onPause();} super.onPause(); }
    @Override protected void onResume() { super.onResume(); if(gameView!=null){gameView.onResume();gameView.evaluateJavascript("window.__pianistResume && window.__pianistResume();", null);} }
    @Override protected void onDestroy() { if(gameView!=null){gameView.destroy();gameView=null;} super.onDestroy(); }
}
