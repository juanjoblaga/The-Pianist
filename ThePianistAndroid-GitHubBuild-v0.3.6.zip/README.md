# The Pianist — v0.3.6 (Android source ZIP)

**This is a playable prototype update, not a finished game or a newly authored narrative.** The approved apartment artwork, protagonist look, and left-portrait dialogue-panel design have been retained. Existing dialogue is explicitly labelled `[TEST]` and awaits the creator's writing.

## Updated in this build

### Movement and the balcony
- **Analog walking speed:** the distance of the thumb from the joystick centre sets the speed, with a dead zone, gradual acceleration and animation cadence following movement speed. Keyboard movement is full speed.
- **Eight movement directions:** upward diagonals now keep the back of the protagonist's head facing away; the previous face-turning composite has been corrected. Diagonal artwork is still assembled from approved cardinal artwork, **not** newly hand-drawn 8-direction frame sequences.
- **Solid balcony railing and glass panels:** only the central sliding-glass opening is passable. The door slides automatically near the character. Walking into the courtyard or over the balcony fence is blocked.
- The sofa / coffee-table gap, nearby walls, bedroom and bathroom remain accessible through foot-based collision regions.

### Apartment and outdoor ambience
- The approved apartment remains the primary composition. Beyond the balcony is an **elegant urban ornamental courtyard**, extending behind the upper scene with subdued paths, refined smaller trees and distant rooflines instead of a separate, visibly cropped rectangle.
- A small **bedroom upper-wall window** offers a second hint of the exterior; it is intentionally a narrow overhead-view window, not a perspective-changing skyline.
- Distinct sunrise (rose/lavender), morning, afternoon, sunset (amber/coral) and night palettes; lighting on the moving character varies with time, outdoor conditions, furniture shade and proximity to lamps.
- Daytime artificial lamp artwork is retouched to appear unlit. Some glow details are still baked into the original illustration; independent per-lamp masking is future refinement.
- Seven weather modes are retained with outdoor-only precipitation and small atmospheric movements.

### Furniture
- The sofa uses a **dedicated horizontal reclining pose**, rather than rotating the seated piano/stool sprite 90 degrees.
- When lying in bed, the protagonist's head remains visible while a foreground textile layer is pulled higher over the body, using the approved duvet pattern at its original scale.
- The portrait dialogue panel and the options to sit/lie on sofa and bed, plus existing balcony and piano interactions, remain available.
- **Limitation:** sitting/reclining pose changes are currently short eased transitions and composited sprites, rather than full bespoke animated sequences with independently drawn frames. Do not treat these as final polished character animation.

### Adjustable controls, persistent settings
- Help (`?`) → **Customize controls** to change joystick size, Interact size, and opacity. Tap **Move controls**, then drag either control; tap **Done positioning** and **Save & close**.
- A **Reset** control is provided. Control settings use `localStorage` key `thepianist.controls.v1` and persist when a **signed APK updates in place without clearing app data**. The package ID and `file:///android_asset/index.html` origin remain unchanged.

### Audio and doors
- The Weather menu's sound button reads `Sound ON` / `Sound OFF`. Procedural rain, storm and wind ambience is still a placeholder, now slightly more audible when enabled.
- Web Audio is suspended when the page or the Android Activity enters the background. Resume is handled on foreground return; volume is still conditional on weather and the saved setting. **Phone-specific audio testing remains necessary.**
- The redundant swing overlays for the apartment entrance/interior doors have been removed to prevent the doubled-door appearance. Those doors retain the original static art; **fully redrawn hinged animations remain unfinished**. The new central balcony slider is animated.

## Build and upgrade

- Application ID: `com.thepianist.game` (unchanged).
- `versionCode`: **9**; `versionName`: **0.3.6**.
- Uses the **exact same signing keystore bytes** as v0.3.5: `app/pianist-prototype-signing.jks`. The debug `assembleDebug` build uses `signingConfigs.pianistPrototype` as before.
- Compatible with the existing GitHub Actions source-ZIP extraction and Gradle 8.9 / JDK 17 / `assembleDebug` workflow.
- The Android WebView app mirrors `game/` under `app/src/main/assets/`. **Keep both mirrors synchronized** when developing further.
- **Back up your existing app data** before installing. Install the new APK **over** your old APK without uninstalling. Updates preserve app data only when the previous installed APK uses the same signing certificate and package name.

## Validation and known limits

- JavaScript syntax checked with Node; browser tests checked new glass/fence collisions, the sofa and bedroom interaction states, the balcony slider, control editor state, background pause flags and successful image rendering with no script errors. Tests used an inline asset document because direct local-file and localhost navigation is restricted in the sandbox.
- Android APK compilation, installation and physical phone gestures **were not tested in this environment**; please test on-device and report screenshots/issues.
- Fine art details remain for a later pass: individual lamp meshes, professionally drawn diagonal and rest animation frames, room-door hinge animation, seamless duvet folds, and richer weather sound recordings.

No game story, narrative directions or authored dialogue were added.
