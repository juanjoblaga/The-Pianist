import json,base64,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
G=Path(__file__).resolve().parents[1]/'game'; OUT=Path(__file__).resolve().parent
images={}
for name in ['walk','sit','courtyard','light_sunrise','light_morning','light_afternoon','light_sunset','light_night','portrait','duvet_foreground','lie_sofa','balcony_threshold']:
 ext='png' if name in ['walk','sit','courtyard','portrait','duvet_foreground','lie_sofa','balcony_threshold'] else 'jpg'
 images[name]='data:image/'+('png' if ext=='png' else 'jpeg')+';base64,'+base64.b64encode((G/(name+'.'+ext)).read_bytes()).decode()
h=(G/'index.html').read_text().replace('<link rel="stylesheet" href="style.css">','<style>'+(G/'style.css').read_text()+'</style>').replace('src="portrait.png"','src="'+images['portrait']+'"')
s=(G/'game.js').read_text().replace("img.src=name+'.'+(['walk','sit','courtyard','duvet_foreground','lie_sofa','balcony_threshold'].includes(name)?'png':'jpg');", "img.src=window.__testData[name];")
h=h.replace('<script src="game.js"></script>', '<script>window.__testData='+json.dumps(images)+';</script><script>'+s+'</script>')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu-sandbox'])
 page=browser.new_page(viewport={'width':1536,'height':768},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(h,wait_until='load',timeout=60000);page.wait_for_timeout(950)
 print('loaded',page.evaluate("Object.entries(window.__pianistTest.getState()).map(([k,v])=>[k,v])"),flush=True)
 checks=page.evaluate('''() => {
 const ok=window.__pianistTest.passable;
 return {fence:ok(690,84),beyond:ok(690,40),fixedGlass:ok(490,209),glassOpening:ok(614,209),balcony:ok(560,145),living:ok(614,243),gap:ok(470,362),nearWall:ok(258,483),bedroom:ok(947,567),bathroom:ok(1043,805)};
 }''')
 print('geometry',checks,flush=True)
 assert not checks['fence'] and not checks['beyond'] and not checks['fixedGlass']
 assert checks['glassOpening'] and checks['balcony'] and checks['living'] and checks['gap'] and checks['bedroom'] and checks['bathroom']
 page.evaluate('window.__pianistTest.setPlayer(611,232,"up")')
 page.wait_for_timeout(700)
 page.screenshot(path=str(OUT/'v036_qa_door_open.png'))
 print('door open level',page.evaluate('window.__pianistTest.getState().balconyOpening'),flush=True)
 page.evaluate('window.__pianistTest.setPlayer(610,142,"down")')
 page.wait_for_timeout(800);page.screenshot(path=str(OUT/'v036_qa_courtyard.png'))
 # sofa test
 page.evaluate('window.__pianistTest.setPlayer(469,361,"up")');page.wait_for_timeout(50)
 page.locator('#action').dispatch_event('pointerdown');page.wait_for_timeout(130)
 print('sofa choices',page.locator('#dialoguechoices button').all_text_contents(),flush=True)
 assert page.locator('#dialoguechoices button').count()>=2
 page.locator('#dialoguechoices button').nth(1).dispatch_event('pointerdown')
 page.wait_for_timeout(1600)
 print('sofa state',page.evaluate('window.__pianistTest.getState().pose'),flush=True)
 page.screenshot(path=str(OUT/'v036_qa_sofa_lie.png'))
 # bed test
 page.evaluate('window.__pianistTest.setPlayer(1104,581,"up")');page.wait_for_timeout(65)
 page.locator('#action').dispatch_event('pointerdown');page.wait_for_timeout(120)
 print('bed choices',page.locator('#dialoguechoices button').all_text_contents(),flush=True)
 page.locator('#dialoguechoices button').nth(1).dispatch_event('pointerdown');page.wait_for_timeout(1600)
 print('bed state',page.evaluate('window.__pianistTest.getState().pose'),flush=True)
 page.screenshot(path=str(OUT/'v036_qa_bed_duvet.png'))
 # settings open and customize size/position; survives reload
 page.locator('#help').click();page.locator('#controlEdit').click();page.locator('#padSize').fill('162');
 page.locator('#controlsOpacity').fill('85');page.locator('#closeControls').click()
 print('configured controls',page.evaluate('window.__pianistTest.getState().layout'),flush=True)
 page.wait_for_timeout(80)
 print('post-edit layout',page.evaluate('window.__pianistTest.getState().layout'),flush=True)
 assert page.evaluate('window.__pianistTest.getState().layout.pad.size')==162
 # background policy
 page.evaluate('window.__pianistPause()');assert page.evaluate('window.__pianistTest.getState().gamePaused') is True
 page.evaluate('window.__pianistResume()');assert page.evaluate('window.__pianistTest.getState().gamePaused') is False
 print('js errors',errors,flush=True)
 assert not errors,errors
 browser.close()

print('PASS')
