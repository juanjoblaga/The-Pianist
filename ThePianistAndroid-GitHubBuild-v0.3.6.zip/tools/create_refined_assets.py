from PIL import Image,ImageDraw,ImageFilter
import math, random
from pathlib import Path
P=Path(__file__).resolve().parents[1]/'game'
random.seed(43)
# A continuous, low-contrast top-down courtyard; upper screen is a subdued urban garden,
# not a floating rectangular image. Render at half-scale and upscale for cohesive pixel detail.
S=2; W,H=768,210
im=Image.new('RGBA',(W,H),(16,23,32,255));d=ImageDraw.Draw(im,'RGBA')
def rect(box,fill,outline=None,width=1):d.rectangle(box,fill=fill,outline=outline,width=width)
def poly(coords,fill):d.polygon(coords,fill=fill)
def ellipse(box,fill,outline=None,width=1):d.ellipse(box,fill=fill,outline=outline,width=width)
# background blends to surrounding dark UI at left and right (no hard band)
for y in range(H):
 t=y/H
 col=(int(27+35*t),int(35+45*t),int(39+39*t),255)
 d.line([(0,y),(W,y)],fill=col)
# urban slate/tile roof zones in the farthest distance (strict overhead)
for x,w in [(123,149),(308,127),(498,143)]:
 rect((x,4,x+w,55),(40,51,58,255),(18,27,37,255),3)
 rect((x+7,10,x+w-8,44),(69,78,78,255))
 for xx in range(x+19,x+w-12,16):d.line([(xx,12),(xx,44)],fill=(89,99,95,170),width=1)
 for xx in range(x+30,x+w-20,45):rect((xx,21,xx+19,35),(58,82,88,255),(31,45,51,255),2)
# low landscape base
poly([(104,47),(661,47),(699,95),(692,209),(85,209),(77,97)],(78,103,89,255))
poly([(128,56),(637,56),(690,103),(677,210),(95,210),(94,110)],(103,131,102,255))
# warm stone promenade, slightly curved path, paving seams
poly([(65,171),(162,144),(258,150),(339,111),(430,117),(553,144),(696,120),(737,178),(704,210),(58,210)],(166,158,138,255))
poly([(67,168),(162,141),(258,147),(339,108),(430,114),(553,141),(696,117),(737,175),(737,180),(695,123),(553,147),(430,121),(339,115),(258,155),(162,148),(67,175)],(207,191,158,255))
for i in range(65):
 x=random.randint(102,681);y=random.randint(80,208)
 if abs(y-(145+13*math.sin(x*.018)))<43:
  rr=random.choice([2,3,4]);d.line([(x,y),(x+rr,y)],fill=(113,120,107,85),width=1)
# neat shrub beds and tree shadows (ornamental, deliberate)
for x,y,rx,ry in [(178,127,62,42),(346,83,42,35),(589,121,71,49),(707,165,31,29)]:
 ellipse((x-rx+7,y-ry+12,x+rx+12,y+ry+15),(19,44,44,120))
 ellipse((x-rx,y-ry,x+rx,y+ry),(61,87,64,255))
 ellipse((x-rx+8,y-ry+7,x+rx-8,y+ry-7),(84,112,76,255))
 for i in range(19):
  phi=i*2.4; r=.35+random.random()*.55
  a=x+math.cos(phi)*rx*r;b=y+math.sin(phi)*ry*r
  ellipse((a-4,b-2,a+5,b+3),random.choice([(108,128,83,220),(97,115,68,210),(74,99,74,220)]))
# elegant slender-trunk trees, with asymmetrical deep leafy clusters and deliberate dark pockets
def tree(x,y,r,seed):
 rng=random.Random(seed)
 # cast shadow, trunk visible only small gap, then delicate crown
 ellipse((x-r+14,y-r+19,x+r+15,y+r+22),(16,39,37,75))
 d.line([(x,y+12),(x+3,y+29)],fill=(81,72,55,255),width=7)
 d.line([(x+3,y+6),(x+13,y-10)],fill=(93,78,57,255),width=3)
 for j in range(12):
  theta=j*2*math.pi/12;rad=r*(.42+.15*rng.random())
  cx=x+math.cos(theta)*rad;cy=y+math.sin(theta)*rad*.78
  rr=r*(.30+.075*rng.random())
  ellipse((cx-rr,cy-rr*.78,cx+rr,cy+rr*.78),rng.choice([(43,70,59,255),(48,78,61,255),(58,90,66,255),(64,89,73,255)]))
 for j in range(8):
  theta=j*2*math.pi/8+.22;rad=r*(.24+.4*rng.random());cx=x+math.cos(theta)*rad;cy=y+math.sin(theta)*rad*.7
  rr=r*(.19+.04*rng.random())
  ellipse((cx-rr,cy-rr*.78,cx+rr,cy+rr*.78),rng.choice([(84,115,79,255),(97,128,85,255),(112,136,89,255),(72,106,75,255)]))
 for j in range(20):
  xx=x+rng.uniform(-.7,.7)*r;yy=y+rng.uniform(-.54,.5)*r
  ellipse((xx,yy,xx+2,yy+2),rng.choice([(178,169,111,210),(166,176,112,190),(80,102,72,180)]))
for x,y,r,seed in [(235,112,45,5),(430,70,35,4),(551,134,48,7),(692,78,37,8)]: tree(x,y,r,seed)
# a refined geometric bench and discrete planters
for x,y in [(323,174),(630,189)]:
 ellipse((x-20,y-3,x+21,y+13),(31,47,40,70))
 rect((x-17,y-4,x+18,y+4),(91,75,59,255),(42,48,46,255),2)
 for yy in (-1,2):d.line([(x-13,y+yy),(x+15,y+yy)],fill=(163,129,85,200),width=1)
# subtle garden lamps, no bright day glows; night renderer adds localized glow
for x,y in [(293,80),(637,99)]:
 ellipse((x-4,y+2,x+7,y+9),(22,35,33,95));ellipse((x-3,y-4,x+4,y+3),(36,41,44,255),(188,168,126,255),1)
# soften hard margins with physically continuous vignetting, including bottom fade
mask=Image.new('L',(W,H));mp=mask.load()
for y in range(H):
 for x in range(W):
  horiz=min(1,max(0,(x-44)/81),max(0,(W-44-x)/81))
  vert=min(1,max(0,(H-y)/44))
  mp[x,y]=int(255*horiz*vert)
im.putalpha(mask)
im.resize((1536,420),Image.Resampling.NEAREST).save(P/'courtyard.png')
# Transparent overlay on top of the existing bed image. First fifty rows lie
# above the original textile and represent the duvet pulled higher over body.
a=Image.open(P/'light_afternoon.jpg').convert('RGB')
# The EXISTING blanket motif is copied at 1:1 pixel scale, never stretched.
# Only the upper part is raised across the white sheet; lower patterned part remains intact.
tex=a.crop((995,409,1210,491))
cover=Image.new('RGBA',(222,130),(0,0,0,0))
cover.paste(tex,(4,11))
# a subtle fold/shadow along the top edge; progressively blend into original blanket below
ca=Image.new('L',(222,130));ma=ImageDraw.Draw(ca)
for y in range(11,84):
 op=255 if y<=61 else int(255*max(0,(83-y)/22))
 if op>0:ma.line([(7,y),(217,y)],fill=op,width=1)
cover.putalpha(ca)
shadow=Image.new('RGBA',(222,130));sd=ImageDraw.Draw(shadow)
sd.arc((6,3,218,22),180,360,fill=(20,36,50,155),width=3)
cover=Image.alpha_composite(shadow,cover)
cover.save(P/'duvet_foreground.png')
print('assets created: courtyard, duvet, lie_sofa')
# The centre sliding opening must REPLACE the painted fixed mullion, not overlay a second door.
# Interior wood / exterior decking sampling comes from the approved image itself.
src=Image.open(P/'light_afternoon.jpg').convert('RGB')
threshold=Image.new('RGBA',(89,68));tr=ImageDraw.Draw(threshold)
# outdoor decking from adjacent unobstructed deck
for y in range(0,35):
 sample=src.crop((640,128+(y%23),729,129+(y%23)))
 threshold.paste(sample,(0,y))
# floor texture taken from the same planks immediately inside the opening
for y in range(35,68):
 sample=src.crop((640,238+(y%22),729,239+(y%22)))
 threshold.paste(sample,(0,y))
tr.line([(0,38),(88,38)],fill=(55,66,70,255),width=4)
tr.line([(0,41),(88,41)],fill=(184,180,160,255),width=2)
# upright bright recessed rail tracks remain at edges (centre stays clear)
tr.rectangle((0,1,6,59),fill=(175,174,164,255));tr.line([(8,1),(8,59)],fill=(55,66,68,255),width=3)
tr.rectangle((81,1,88,59),fill=(157,165,161,255));tr.line([(79,1),(79,59)],fill=(52,66,72,255),width=3)
threshold.save(P/'balcony_threshold.png')
print('balcony threshold created')
# Distinct colours for the same approved apartment plate; lighting is recomposed per mode.
import numpy as np
base=np.asarray(src,dtype=np.float32)/255
hh,ww=base.shape[:2];yy,xx=np.mgrid[0:hh,0:ww].astype('float32')
def soft(x,y,sx,sy):return np.exp(-.5*((xx-x)/sx)**2-.5*((yy-y)/sy)**2)[...,None]
# Do not touch the physical design, only local radiance and base ambient palettes.
options={
 'sunrise':(np.array([.92,.93,1.03]),np.array([1.0,.68,.84]),.145,np.array([1.0,.79,.63]),.19,(720,252,340,300)),
 'morning':(np.array([1.03,1.04,1.06]),np.array([1.,.97,.84]),.07,np.array([1.,.93,.73]),.11,(655,250,285,280)),
 'afternoon':(np.array([1.02,1.04,1.04]),np.array([1.,.97,.94]),.035,np.array([1.,.96,.85]),.07,(775,270,370,320)),
 'sunset':(np.array([.92,.85,.94]),np.array([1.,.60,.43]),.185,np.array([1.,.71,.42]),.30,(690,285,450,325))
}
for name,(ambient,tint,mix,warm,strength,gpar) in options.items():
 plate=base*ambient
 plate=(plate*(1-mix)+tint*mix)
 power=soft(*gpar)*strength
 plate=plate*(1-power)+warm*power
 # wood and bedding stay detailed: no heavy crushing of contrast
 out=(np.clip(plate,0,1)*255).astype(np.uint8)
 # Unlit piano lamp: preserve its little shade and remove the incandescent core.
 if name!='night':
  from PIL import ImageDraw
  im=Image.fromarray(out,'RGB')
  import cv2
  ar=np.array(im)
  mask=np.zeros((hh,ww),np.uint8)
  cv2.ellipse(mask,(849,320),(13,20),0,0,360,255,-1)
  ar=cv2.inpaint(ar,mask,5,cv2.INPAINT_TELEA)
  im=Image.fromarray(ar,'RGB');d=ImageDraw.Draw(im)
  d.ellipse((843,309,857,329),fill='#8c8b80',outline='#46494a',width=2)
  d.arc((845,311,855,327),193,340,fill='#c2b9a5',width=2)
  out=np.array(im)
 Image.fromarray(out,'RGB').save(P/f'light_{name}.jpg',quality=95,subsampling=0)
print('distinct day palettes generated')
