from PIL import Image,ImageDraw
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'game/walk.png'
a=Image.open(p).convert('RGBA')
# Real orientations matter more than falsely front-facing diagonal portraits.
# Down diagonals: profile head/neck blended with front-facing torso and side legs.
# Up diagonals: the ORIGINAL rear head (no forward-facing eyes) with asymmetric side leg steps.
def frame(row,i):return a.crop((i*80,row*112,(i+1)*80,(row+1)*112)).copy()
for i in range(4):
 front=frame(0,i); back=frame(3,i); left=frame(1,i); right=frame(2,i)
 for row,profile in [(4,left),(5,right)]:
  # A clean side-facing head and walking pose: no camera-facing face pasted over profile.
  # Lightly soften torso towards the viewer using front-shirt highlight pixels.
  diag=profile.copy()
  torso=front.crop((27,57,49,79))
  diag.alpha_composite(torso,(28 if row==4 else 30,57))
  # Preserve the side-facing profile all the way through the jaw/neck.
  face=profile.crop((9,5,69,67));diag.alpha_composite(face,(9,5))
  a.paste(diag,(i*80,row*112))
 for row,profile in [(6,left),(7,right)]:
  diag=back.copy()
  # Keep the original BACK OF HEAD; only legs / lowered arm communicate diagonal direction.
  leg=profile.crop((11,82,68,112))
  diag.alpha_composite(leg,(11,82))
  # preserve shoulders/back shirt from original back frame
  backtorso=back.crop((21,51,62,90));diag.alpha_composite(backtorso,(21,51))
  a.paste(diag,(i*80,row*112))
a.save(p)
print('Diagonals redrawn without forward-facing eyes in rear views')
